# 本地 + AWS 使用手册

本地目录、S3 存储、AWS Batch 和 SageMaker 使用同一任务结构与复核格式。默认完全本地；不需要原 4090 SSH 服务。

## 1. 本地启动

推荐 Python 3.11 或 3.12。`Start-Local.ps1` 创建独立虚拟环境并安装依赖，然后启动页面。Windows 执行：

```powershell
cd <解压目录>/nba-assist
./Start-Local.ps1
```

或启动 Docker Desktop 后执行：

```powershell
docker compose up --build -d
```

浏览器打开 http://127.0.0.1:8768。把视频和 `.pt` 模型放入 `workspace/`；Docker 页面里填写 `/workspace/video.mp4` 和 `/workspace/model.pt`。也可从页面上传视频。**源码包不附带训练权重**，需要复制通用权重和已有 `best.pt`。没有 NVIDIA GPU 时自动使用 CPU，速度会显著下降。

NVIDIA GPU + Docker GPU 运行时可用时：

```powershell
docker compose -f compose.yaml -f compose.gpu.yaml up --build -d
```

Docker 仅将宿主机回环地址暴露为 8768；容器内部绑定 0.0.0.0 是端口映射所需。不要将没有身份认证的此工具直接暴露到公网。

## 2. 本地推理 + S3 保存

复制 `.env.example` 为 `.env`，设置：

```dotenv
NBA_STORAGE=s3
NBA_EXECUTOR=local
NBA_S3_BUCKET=your-existing-bucket
NBA_S3_PREFIX=nba-assist
AWS_DEFAULT_REGION=us-east-1
```

原生 Python 启动需把这些值设为系统/终端环境变量；Python 不自动读取 `.env`。Docker Compose 自动读取同目录 `.env`。

本地 AWS CLI 凭据/SSO profile 使用标准 AWS SDK 凭据链。容器可使用 `compose.aws.yaml` 只读挂载现有凭据目录：

```powershell
$env:AWS_CONFIG_DIR="$env:USERPROFILE/.aws"
$env:AWS_PROFILE="your-profile"
docker compose -f compose.yaml -f compose.aws.yaml up --build -d
```

在 EC2/Batch/SageMaker 上优先使用 IAM 执行角色，无需写入密钥。MinIO 等 S3 兼容服务可额外设置 `NBA_S3_ENDPOINT`，使用 SDK 标准凭据变量。

本地推理完成后会保存 S3 结果包。人工复核保存在本地 SQLite；复核后的 ZIP 由页面导出，**不会自动同步后续人工修订到 S3**。可使用 AWS CLI `aws s3 cp` 上传导出包。

## 3. AWS Batch

先由账号管理员准备 S3 桶、ECR 镜像、GPU 计算环境、队列和作业定义。镜像由同一个 Dockerfile 构建并上传你自己的 ECR。作业定义使用该镜像，并为需要 GPU 的任务配置 GPU resource requirement 和足够内存/磁盘。设置：

```dotenv
NBA_STORAGE=s3
NBA_EXECUTOR=aws-batch
NBA_BATCH_QUEUE=your-queue
NBA_BATCH_JOB_DEFINITION=your-job-definition:1
NBA_BATCH_ATTEMPTS=1
NBA_MAX_SECONDS=7200
```

页面提交后：上传视频和模型 → Batch 作业执行 `python -m nba_assist.cloud_runtime` → S3 保存结果 → 本地下载 → 页面复核。作业 IAM 角色需要读取输入和模型、写入结果前缀。提交者需要 Batch submit/describe 及访问相关 S3 对象权限。

## 4. SageMaker 自定义容器

使用 SageMaker Training Job 作为限时 GPU 批处理容器运行本工具（名称是 Training Job，实际执行当前识别任务，不会自动训练新权重）。设置：

```dotenv
NBA_STORAGE=s3
NBA_EXECUTOR=sagemaker
NBA_SAGEMAKER_ROLE_ARN=arn:aws:iam::<account-id>:role/<execution-role>
NBA_SAGEMAKER_IMAGE=<account-id>.dkr.ecr.<region>.amazonaws.com/nba-assist:<tag>
NBA_SAGEMAKER_INSTANCE=ml.g5.xlarge
NBA_VOLUME_GB=100
NBA_MAX_SECONDS=7200
```

调用者需要 CreateTrainingJob/DescribeTrainingJob 和对应执行角色的 iam:PassRole。执行角色需读取 S3 输入/模型、写结果和拉取 ECR 镜像。这里未创建 IAM/ECR/Batch 资源；账号、区域、权限及配额必须由部署环境提供。

## 5. Agent / CLI

设置存储/执行后端环境变量后，同一 CLI 可用于本地或云端：

```powershell
python -m nba_assist.portable prepare --video workspace/game.mp4 --model workspace/yolo11s.pt --game-id game-2026-01 --out job.json --seconds 30 --fps 10
python -m nba_assist.portable submit --spec job.json --receipt receipt.json
python -m nba_assist.portable monitor --receipt receipt.json
python -m nba_assist.portable review --result s3://your-bucket/nba-assist/results/JOB_ID/result.zip --job-id JOB_ID --root data
```

本地 submit 同步执行，云端 submit 返回回执。`prepare --options options.json` 可传入 `roster/team_colors/ocr/device/imgsz/aliases`。云端入口当前支持这些字段；PBP/gallery 文件使用本地模式。GUI 中填入名单路径会在上传前转换成内联名单。

导出沿用浏览器和原 CLI。训练数据仍按整场比赛分割；不会自动把未知身份当真值。

## 6. 失败、成本和验证边界

- AWS SDK 使用其标准重试行为；Batch 尝试次数可配置，默认 1，运行时间默认上限 7200 秒。超时不是费用预算，GPU 规格和运行时长决定费用。
- 推理失败会尽量发布带错误和已保存帧的结果包。每次重试从头推理；**没有帧级断点续跑**。
- 本地服务重启不会自动恢复云端监控；保留 `cloud_receipt.json`，可用 monitor 继续查状态，再下载结果。
- 输入视频和模型分块计算 SHA256，模型原件不会写入结果包。
- 27 项测试通过，包含真实 botocore Stubber 校验；没有访问实际 AWS 账号。
- 当前电脑 Docker Desktop 引擎未运行，Compose 配置验证通过，镜像构建与容器启动尚未实测。
- 原版已在 4090 上跑通短视频；本次新增本地/云端封装尚未进行 AWS GPU 实测，不能称为已在 AWS 验收。
