# NBA Assist Implementation Plan

**Goal:** Deliver a working local-browser assistant with real server inference, review, exports, and explicit validation limits.

**Architecture:** A standard-library HTTP service orchestrates bounded subprocess jobs. Inference dependencies load only in worker jobs. Immutable observations and append-only review revisions are reduced into corrected frame records; exports consume the same corrected state.

**Tech Stack:** Python 3.10+, stdlib HTTP/SQLite/JSON, OpenCV, Ultralytics/ByteTrack, optional EasyOCR, plain browser canvas.

**Spec:** design.md (approved in chat).

## Global constraints
- All class/name/number guesses remain provisional until human confirmation.
- Do not mutate existing model weights, dataset or running jobs.
- Time labels use source-video seconds, never assume game-clock equivalence.
- Fail clearly on unavailable inference or OCR; record dependencies and hashes.
- Serve only tool-owned files; reject traversal and input paths outside configured root.

## Review focus
- Named detector classes must remain usable and cannot suppress generic unknown players.
- New shot IDs must not reuse previous shot identity votes.
- Partial frame edits cannot silently enter training as complete ground truth.
- Track edits must be shot scoped and time bounded.
- Unaligned official events cannot acquire invented video timestamps.

## Tasks
1. Core evidence and review contract (`nba_assist/core.py`, `tests/test_core.py`): test named class acceptance, independent number votes/conflicts, scoped revisions, geometry validation, empty/unknown inputs; implement normalization and revision reducer.
2. Exports/evaluation (`nba_assist/export.py`, `nba_assist/evaluate.py`, tests): test fully reviewed frame filtering, normalized coordinates, match-level leakage rejection, independent detection/identity/event metrics; implement ZIP exports, dataset builder and evaluator.
3. Inference (`nba_assist/worker.py`, `nba_assist/vision.py`): integrate generic detections and custom candidates, ByteTrack, scene cuts, torso color, optional jersey OCR, roster and gallery retrieval; record per-frame evidence and errors; validate on server sample and existing game frames.
4. Review service (`nba_assist/server.py`, `web/index.html`): isolated SQLite jobs, bounded local video uploads, server path selection, task progress, canvas edits, frame approval, track changes and events; test live HTTP creation/revision/export, errors and traversal.
5. Verification and delivery: run unit/integration tests, real GPU inference, export/reimport checks and annotated-video rendering; document exact observed results and missing new-game validation.

Execution is native in the current session under the user's confirmed implementation authorization. Each functional task starts with failing behavior tests, then implementation and verification. No further design approval is needed for routine implementation choices.
