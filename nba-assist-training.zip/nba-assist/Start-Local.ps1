$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
New-Item -ItemType Directory -Force -Path data,workspace | Out-Null
if (-not (Test-Path -LiteralPath .venv/Scripts/python.exe)) { python -m venv .venv }
& .venv/Scripts/python.exe -m pip install -r requirements.txt -r requirements-cloud.txt
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed' }
Write-Host 'Open http://127.0.0.1:8768 after the service starts. Put video and weights in workspace/.'
& .venv/Scripts/python.exe -m nba_assist.server --root data --allowed-root workspace
