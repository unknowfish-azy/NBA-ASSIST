import os,tempfile,unittest
from pathlib import Path
from nba_assist.cloud import LocalStore,JobSpec,make_store

class CloudTests(unittest.TestCase):
    def test_local_store_round_trip_and_safe_key(self):
        with tempfile.TemporaryDirectory() as d:
            s=LocalStore(d);s.put_bytes('jobs/a/input.json',b'{}');self.assertEqual(s.get_bytes('jobs/a/input.json'),b'{}')
            with self.assertRaises(ValueError):s.get_bytes('../secret')
    def test_job_spec_is_deterministic_and_has_no_secret(self):
        spec=JobSpec(game_id='g',input_uri='s3://bucket/in.mp4',model_uri='s3://bucket/model.pt',output_uri='s3://bucket/out',executor='aws-batch')
        payload=spec.to_dict();self.assertEqual(payload['schema'],'nba.assist.job.v1');self.assertNotIn('AWS_SECRET_ACCESS_KEY',str(payload));self.assertEqual(spec.id,spec.id)
    def test_backend_defaults_local_and_rejects_unknown(self):
        with tempfile.TemporaryDirectory() as d:
            old=os.environ.pop('NBA_STORAGE',None)
            try:self.assertIsInstance(make_store(d),LocalStore)
            finally:
                if old is not None:os.environ['NBA_STORAGE']=old
        os.environ['NBA_STORAGE']='bad'
        try:
            with self.assertRaises(ValueError):make_store('x')
        finally:os.environ.pop('NBA_STORAGE',None)
if __name__=='__main__':unittest.main()
