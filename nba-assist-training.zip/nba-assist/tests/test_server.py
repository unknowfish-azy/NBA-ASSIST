import unittest,tempfile,json,threading,urllib.request,urllib.error
from pathlib import Path
from nba_assist import server

class ServerTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.app=server.Application(self.root,self.root)
        self.http=server.make_server(self.app,port=0)
        self.thread=threading.Thread(target=self.http.serve_forever,daemon=True);self.thread.start()
        self.url='http://127.0.0.1:'+str(self.http.server_address[1])
    def tearDown(self):
        self.http.shutdown();self.http.server_close();self.tmp.cleanup()
    def request(self,path,data=None):
        req=urllib.request.Request(self.url+path,data=None if data is None else json.dumps(data).encode(),headers={'Content-Type':'application/json'})
        with urllib.request.urlopen(req) as r:return json.load(r)
    def test_health_and_path_boundary(self):
        self.assertEqual(self.request('/api/health')['status'],'ok')
        with self.assertRaises(ValueError):self.app.allowed_path(self.root.parent/'secret')
    def test_edits_export_and_reviewer_required(self):
        job={'id':'fixture','game_id':'g','status':'complete','width':100,'height':100,'frames':[{'index':0,'file':'000000.jpg','timestamp':0,'shot_id':0}], 'events':[]}
        p=self.app.jobs/'fixture';p.mkdir();(p/'frames').mkdir();(p/'frames/000000.jpg').write_bytes(b'jpg')
        (p/'manifest.json').write_text(json.dumps(job));(p/'observations.jsonl').write_text(json.dumps({'id':'a','frame':0,'shot_id':0,'track_id':'0:1','kind':'player','bbox':[0,0,10,10]})+'\n')
        with self.assertRaises(urllib.error.HTTPError) as cm:self.request('/api/jobs/fixture/review',{'op':'approve_frame','frame':0})
        cm.exception.close()
        self.request('/api/jobs/fixture/review',{'op':'update','id':'a','changes':{'team':'DAL'},'reviewer':'reviewer'})
        self.request('/api/jobs/fixture/review',{'op':'approve_frame','frame':0,'reviewer':'reviewer'})
        state=self.request('/api/jobs/fixture')
        self.assertEqual(state['observations'][0]['team'],'DAL');self.assertEqual(state['approved_frames'],[0])
        self.assertTrue(self.request('/api/jobs/fixture/export',{'training':True})['url'].endswith('.zip'))
    def test_cross_origin_write_rejected(self):
        req=urllib.request.Request(self.url+'/api/jobs',data=b'{}',headers={'Origin':'https://evil.example','Content-Type':'application/json'})
        with self.assertRaises(urllib.error.HTTPError) as cm:urllib.request.urlopen(req)
        self.assertEqual(cm.exception.code,403)
        cm.exception.close()

if __name__=='__main__':unittest.main()
