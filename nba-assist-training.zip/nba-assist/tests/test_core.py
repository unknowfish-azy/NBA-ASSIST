import unittest
from nba_assist import core

class EvidenceTests(unittest.TestCase):
    def test_named_classes_are_candidates(self):
        self.assertEqual(core.class_kind('kevin_durant', {'kevin_durant':'201142'}), 'player')
        self.assertEqual(core.class_kind('basketball', {}), 'ball')
        self.assertIsNone(core.class_kind('car', {}))
    def test_null_jerseys_remain_null(self):
        r=core.normalize_roster({'players':[{'player_id':1,'name':'A','team':'HOU','jersey':None}]})
        self.assertIsNone(r[0]['jersey_number'])
    def test_independent_votes_conflict_and_shot_reset(self):
        r=core.IdentityResolver([{'player_id':'1','team':'HOU','jersey_number':'7'},{'player_id':'2','team':'HOU','jersey_number':'8'}])
        for t in (0,.01,.02): result=r.update('0:1',t,'HOU','7',.99)
        self.assertEqual(result['status'],'unknown')
        for t in (.6,1.2): result=r.update('0:1',t,'HOU','7',.99)
        self.assertEqual(result['player_id'],'1');self.assertEqual(result['status'],'provisional')
        self.assertEqual(r.update('0:1',2,'HOU','8',.99)['status'],'unknown')
        self.assertEqual(r.update('1:1',2.5,'HOU','7',.99)['status'],'unknown')
    def test_scoped_track_review_does_not_mutate_raw(self):
        rows=[{'id':str(i),'frame':i,'shot_id':s,'track_id':'0:1','bbox':[0,0,10,10],'kind':'player'} for i,s in [(0,0),(1,0),(2,1)]]
        edit={'op':'track','track_id':'0:1','shot_id':0,'start_frame':1,'end_frame':2,'changes':{'player_id':'9','track_id':'0:9'},'reviewer':'Alice'}
        got=core.reduce_reviews(rows,[edit],100,100)
        self.assertNotIn('player_id',got[0]);self.assertEqual(got[1]['player_id'],'9')
        self.assertNotIn('player_id',got[2]);self.assertNotIn('player_id',rows[1])
    def test_invalid_geometry_and_approval_invalidation(self):
        rows=[{'id':'a','frame':0,'shot_id':0,'track_id':'0:1','bbox':[0,0,10,10],'kind':'player'}]
        with self.assertRaises(ValueError): core.reduce_reviews(rows,[{'op':'update','id':'a','changes':{'bbox':[-1,0,10,10]}}],100,100)
        self.assertEqual(core.approved_frames([{'op':'approve_frame','frame':0},{'op':'update','frame':0}]),set())
    def test_pbp_does_not_invent_video_time(self):
        e=core.import_events({'game':{'actions':[{'actionId':3,'actionType':'Foul','clock':'PT10M15.00S','period':1}]}})[0]
        self.assertEqual(e['kind'],'foul');self.assertIsNone(e['start']);self.assertEqual(e['status'],'unaligned')
    def test_shot_crossing_is_candidate_and_gap_resets(self):
        r=core.ShotCandidates()
        self.assertEqual(r.update(0,[50,30],[40,40,60,50],0),[])
        got=r.update(.04,[50,60],[40,40,60,50],0)
        self.assertEqual(got[0]['status'],'candidate');self.assertEqual(got[0]['kind'],'shot')
        r.update(.08,None,[40,40,60,50],0)
        self.assertEqual(r.update(.12,[50,60],[40,40,60,50],0),[])

if __name__=='__main__':unittest.main()
