import json,tempfile,unittest
import time
from pathlib import Path
from nba_assist.training import TrainingSpec,validate_spec
from nba_assist.training import run_local,refresh,stop

class TrainingTests(unittest.TestCase):
    def wait(self,root,id):
        deadline=time.monotonic()+20
        while time.monotonic()<deadline:
            s=refresh(root,id)
            if s['status'] not in ('queued','running'):return s
            time.sleep(.1)
        self.fail('training did not finish')
    def test_real_process_success_metrics_failure_and_stop(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);script=root/'train.py'
            script.write_text("import os,json\nfrom pathlib import Path\np=Path(os.environ['NBA_OUTPUT_DIR']);(p/'metrics.json').write_text(json.dumps({'loss':0.25}));(p/'weights.bin').write_bytes(b'test-only');print('finished')")
            s=TrainingSpec('g',str(script),[],d,str(root/'out'));run_local(s,root)
            result=self.wait(root,s.job_id);self.assertEqual(result['exit_code'],0);self.assertEqual(result['metrics']['loss'],.25);self.assertIn('finished',result['log_tail'])
            script.write_text('raise SystemExit(7)');s=TrainingSpec('g',str(script),[],d,str(root/'fail'));run_local(s,root)
            result=self.wait(root,s.job_id);self.assertEqual(result['status'],'failed');self.assertEqual(result['exit_code'],7)
            script.write_text('import time;time.sleep(60)');s=TrainingSpec('g',str(script),[],d,str(root/'stop'));run_local(s,root);stop(root,s.job_id)
            self.assertEqual(self.wait(root,s.job_id)['status'],'stopped')
    def test_timeout_is_not_success(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);p=root/'wait.py';p.write_text('import time;time.sleep(60)')
            s=TrainingSpec('g',str(p),[],d,str(root/'out'),max_seconds=1);run_local(s,root)
            self.assertEqual(self.wait(root,s.job_id)['status'],'timed_out')
    def test_spec_rejects_shell_syntax_and_outside_paths(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);script=root/'train.py';script.write_text('print(1)')
            s=TrainingSpec('g',str(script),['--epochs','1'],str(root),str(root/'out'))
            validate_spec(s,root)
            with self.assertRaises(ValueError):validate_spec(TrainingSpec('g',str(script),['--epochs','1; rm -rf /'],str(root),str(root/'out')),root)
            with self.assertRaises(ValueError):validate_spec(TrainingSpec('g',str(root/'missing.py'),[],str(root),str(root/'out')),root)
    def test_json_does_not_include_secrets_and_is_stable(self):
        s=TrainingSpec('g','/workspace/train.py',['--data','/workspace/data.yaml'],'/workspace','/workspace/runs',backend='aws-batch')
        value=s.to_dict();self.assertEqual(value['schema'],'nba.assist.training.v1');self.assertNotIn('AWS_SECRET_ACCESS_KEY',json.dumps(value))
    def test_script_path_must_be_python_or_known_executable(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);p=root/'evil.sh';p.write_text('echo hi')
            with self.assertRaises(ValueError):validate_spec(TrainingSpec('g',str(p),[],str(root),str(root/'out')),root)
if __name__=='__main__':unittest.main()
