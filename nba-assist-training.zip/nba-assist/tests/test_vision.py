import unittest
from nba_assist import vision

class VisionTests(unittest.TestCase):
    def test_custom_name_evidence_keeps_generic_player_and_unknowns(self):
        generic=[{'kind':'player','bbox':[0,0,20,40],'confidence':.8},{'kind':'player','bbox':[50,0,70,40],'confidence':.9}]
        custom=[{'kind':'player','bbox':[1,1,21,41],'confidence':.7,'candidate_player_id':'7'}]
        result=vision.fuse_detections(generic,custom)
        self.assertEqual(len(result),2);self.assertEqual(result[0]['name_candidate']['player_id'],'7')
        self.assertNotIn('player_id',result[0]);self.assertNotIn('name_candidate',result[1])
    def test_ball_duplicates_removed_without_discarding_small_ball(self):
        g=[{'kind':'ball','bbox':[10,10,15,15],'confidence':.5}]
        c=[{'kind':'ball','bbox':[10,10,15,15],'confidence':.7}]
        self.assertEqual(len(vision.fuse_detections(g,c)),1)
    def test_config_rejects_unbounded_or_invalid_jobs(self):
        with self.assertRaises(ValueError):vision.validate_config({'source':'x','game_id':'g','seconds':-1})
        with self.assertRaises(ValueError):vision.validate_config({'source':'x','game_id':'g','seconds':10,'sample_fps':0})

if __name__=='__main__':unittest.main()
