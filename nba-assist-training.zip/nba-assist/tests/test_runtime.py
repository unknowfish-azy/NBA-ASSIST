import unittest,tempfile,json
from pathlib import Path
from nba_assist import cloud_runtime
from nba_assist.cloud import JobSpec
class RuntimeTests(unittest.TestCase):
    def test_stage_local_files_and_keep_job_options(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/'v.mp4').write_bytes(b'video');(p/'m.pt').write_bytes(b'weights')
            spec=JobSpec('game',str(p/'v.mp4'),str(p/'m.pt'),str(p/'out'),options={'device':'cpu','team_colors':{'blue':'DAL'}})
            job=cloud_runtime.stage(spec,p/'scratch')
            c=json.loads((job/'config.json').read_text())
            self.assertEqual(c['team_colors'],{'blue':'DAL'});self.assertEqual(Path(c['source']).read_bytes(),b'video')
            self.assertEqual(len(c['input_sha256']),64)
    def test_archive_rejects_traversal(self):
        import zipfile
        with tempfile.TemporaryDirectory() as d:
            z=Path(d)/'evil.zip'
            with zipfile.ZipFile(z,'w') as f:f.writestr('../evil',b'x')
            with self.assertRaises(ValueError):cloud_runtime.restore(z,Path(d)/'target')
    def test_aws_contract_rejects_local_input(self):
        with self.assertRaises(ValueError):JobSpec('g','C:/video.mp4','s3://b/m','s3://b/out',executor='aws-batch')
