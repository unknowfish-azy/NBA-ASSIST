import os,unittest
from unittest.mock import patch
try:
    import boto3
    from botocore.stub import Stubber,ANY
except ImportError:boto3=None
from nba_assist.cloud import JobSpec
from nba_assist.executor import submit_batch,submit_sagemaker

@unittest.skipIf(boto3 is None,'boto3 optional')
class AwsRequests(unittest.TestCase):
    def spec(self,backend):return JobSpec('g','s3://bucket/v.mp4','s3://bucket/m.pt','s3://bucket/results',executor=backend,job_id='abc123')
    def client(self,service):return boto3.client(service,region_name='us-east-1',aws_access_key_id='testing',aws_secret_access_key='testing')
    def test_batch_actual_sdk_serialization(self):
        c=self.client('batch');s=self.spec('aws-batch')
        expected={'jobName':'nba-assist-abc123','jobQueue':'queue','jobDefinition':'definition','containerOverrides':{'command':['python','-m','nba_assist.cloud_runtime'],'environment':[{'name':'NBA_JOB_JSON','value':s.json()}]},'retryStrategy':{'attempts':1},'timeout':{'attemptDurationSeconds':7200}}
        with Stubber(c) as stub:
            stub.add_response('submit_job',{'jobName':'nba-assist-abc123','jobId':'aws123'},expected)
            with patch.dict(os.environ,{'NBA_BATCH_QUEUE':'queue','NBA_BATCH_JOB_DEFINITION':'definition','NBA_BATCH_ATTEMPTS':'1','NBA_MAX_SECONDS':'7200'}),patch('boto3.client',return_value=c):
                self.assertEqual(submit_batch(s)['aws_job_id'],'aws123')
            stub.assert_no_pending_responses()
    def test_sagemaker_worker_entry_and_job_environment(self):
        c=self.client('sagemaker');s=self.spec('sagemaker')
        expected={'TrainingJobName':'nba-assist-abc123','RoleArn':'arn:aws:iam::123456789012:role/nba','AlgorithmSpecification':{'TrainingImage':'123456789012.dkr.ecr.us-east-1.amazonaws.com/nba:latest','TrainingInputMode':'File','ContainerEntrypoint':['python','-m','nba_assist.cloud_runtime']},'OutputDataConfig':{'S3OutputPath':'s3://bucket/results'},'ResourceConfig':{'InstanceType':'ml.g5.xlarge','InstanceCount':1,'VolumeSizeInGB':100},'StoppingCondition':{'MaxRuntimeInSeconds':7200},'Environment':{'NBA_JOB_JSON':s.json()}}
        with Stubber(c) as stub:
            stub.add_response('create_training_job',{'TrainingJobArn':'arn:aws:sagemaker:us-east-1:123456789012:training-job/nba-assist-abc123'},expected)
            with patch.dict(os.environ,{'NBA_SAGEMAKER_ROLE_ARN':expected['RoleArn'],'NBA_SAGEMAKER_IMAGE':expected['AlgorithmSpecification']['TrainingImage']}),patch('boto3.client',return_value=c):
                self.assertEqual(submit_sagemaker(s)['aws_job_name'],'nba-assist-abc123')
            stub.assert_no_pending_responses()
