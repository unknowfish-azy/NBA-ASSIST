import unittest, tempfile, json, zipfile
from pathlib import Path
from nba_assist import export, evaluate

class ExportTests(unittest.TestCase):
    def test_training_export_requires_full_frame_review_and_uses_corrected_boxes(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);(p/'frames').mkdir();(p/'frames/000000.jpg').write_bytes(b'image')
            job={'id':'j','game_id':'g','width':100,'height':50,'frames':[{'index':0,'file':'000000.jpg','timestamp':0}]}
            rows=[{'id':'a','frame':0,'shot_id':0,'kind':'player','bbox':[10,10,30,30],'track_id':'0:1'}]
            result=export.make_export(p,job,rows,[],[],training=True)
            with zipfile.ZipFile(result) as z: self.assertNotIn('labels/000000.txt',z.namelist())
            rev=[{'op':'update','id':'a','frame':0,'changes':{'bbox':[20,10,40,30]}}, {'op':'approve_frame','frame':0,'reviewer':'A'}]
            result=export.make_export(p,job,rows,rev,[],training=True)
            with zipfile.ZipFile(result) as z:
                self.assertEqual(z.read('labels/000000.txt').decode().strip(),'0 0.300000 0.400000 0.200000 0.400000')
                self.assertIn('images/000000.jpg',z.namelist())
    def test_split_refuses_same_game_in_train_and_test(self):
        with self.assertRaises(ValueError):export.check_splits({'train':['a'],'val':['b'],'test':['a']})
    def test_metrics_distinguish_unknown_identity_from_wrong_identity(self):
        pred=[{'frame':0,'kind':'player','bbox':[0,0,10,10],'player_id':None,'track_id':'0:1'}]
        truth=[{'frame':0,'kind':'player','bbox':[0,0,10,10],'player_id':'7','track_id':'gt1'}]
        result=evaluate.detection_metrics(pred,truth)
        self.assertEqual(result['recall'],1);self.assertEqual(result['identity_coverage'],0)
        self.assertIsNone(result['identity_accuracy_when_assigned'])
    def test_event_matching_is_one_to_one(self):
        p=[{'kind':'foul','start':3},{'kind':'foul','start':3.1}]
        r=evaluate.event_metrics(p,[{'kind':'foul','start':3}])
        self.assertEqual(r['precision'],.5);self.assertEqual(r['recall'],1)

if __name__=='__main__':unittest.main()
