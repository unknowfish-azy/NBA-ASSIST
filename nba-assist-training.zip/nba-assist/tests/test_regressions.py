import unittest
from nba_assist.core import import_events,merge_event
from nba_assist.export import merged_events
class RegressionTests(unittest.TestCase):
    def test_event_revision_preserves_imported_provenance(self):
        original=import_events({'game':{'gameId':'g','actions':[{'actionId':9,'actionType':'Foul','clock':'PT2M','period':4,'personId':7}]}})[0]
        revised=merge_event(original,{'id':original['id'],'kind':'foul','start':12.5,'end':13.2,'status':'human_confirmed'})
        self.assertEqual(revised['action_id'],9);self.assertEqual(revised['game_clock'],'PT2M');self.assertEqual(revised['start'],12.5)
    def test_event_list_merge_keeps_old_fields(self):
        old={'id':'x','kind':'foul','action_id':1,'game_clock':'PT1M'}
        got=merged_events([old],[{'op':'event','event':{'id':'x','kind':'foul','start':3,'end':4,'status':'human_confirmed'}}])[0]
        self.assertEqual(got['action_id'],1);self.assertEqual(got['start'],3)
if __name__=='__main__':unittest.main()
