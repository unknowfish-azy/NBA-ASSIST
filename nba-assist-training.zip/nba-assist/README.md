# NBA Assist — 比赛辅助识别与标注

**本地和 AWS 兼容版：先阅读 [LOCAL-AWS.md](LOCAL-AWS.md)。** 提供 Windows 原生启动、Docker Compose、S3/MinIO 存储和 AWS Batch/SageMaker 任务适配。下面保留原 4090 部署说明；本地使用不依赖该服务器。

第一版可运行工具：通用球员检测 + 已有姓名模型候选 + ByteTrack 跟踪 + 每场球衣配置 + 可选号码 OCR + 多帧身份投票 + 人工复核 + 标签回流。所有自动身份和事件均为候选，人工确认另存，不覆盖原始预测。

## 已部署的服务器

- 工具：`/root/autodl-tmp/nba/nba-assist`
- 数据/修订：`/root/autodl-tmp/nba/nba_assist_data`
- 独立环境：`/root/autodl-tmp/nba/nba_assist_runtime/bin/python`
- 服务：`127.0.0.1:8768`（仅回环访问）

在自己的电脑打开终端并运行，按提示输入服务器密码；保持终端打开：

```powershell
ssh -p 24485 -N -L 8768:127.0.0.1:8768 root@connect.westb.seetacloud.com
```

然后浏览器访问 <http://127.0.0.1:8768>。

如果本地 8768 被占用，可把 `-L` 改成 `8769:127.0.0.1:8768`，访问本地 8769。

## 使用顺序

1. 填写比赛 ID，选服务器视频路径或上传视频。先处理 30–60 秒。
2. 通用模型用 `yolo11s.pt`；旧比赛模型选 `runs/det/det_m896_e60/weights/best.pt`。
3. 填本场球衣映射，例如 `{"red":"HOU","blue":"DAL"}`。这只是示例，必须确认视频实际球衣；白色归属也应按当场显式配置。
4. 填当场名单。可使用已有名单路径，但已有 2026-02-01 名单号码为空，不能直接当新比赛名单。
5. 需要号码时勾选 OCR。首次需要 EasyOCR 下载权重，网络失败会明确报错；不开 OCR 仍可跟踪、复核和人工标注。
6. 选择已完成任务。点击框编辑球队/姓名 ID/号码/坐标；“拖框补标”添加漏检，删除误检。
7. 轨迹区间修订：相同镜头内统一 ID 可合并；后半段换新 ID 可拆分。修订是区间覆盖，不自动重识别跨镜头人物。
8. 逐帧检查所有目标，确认完整后点击“整帧检查完成”。修改会撤销相应帧审核状态。
9. 事件候选需核实；可手动添加投篮、进球、犯规等事件，填写视频秒数。官方比赛时钟不会自动转换成视频时间。
10. 导出全部标注或已审核训练帧。ZIP 包含 YOLO 通用类别、LabelMe、轨迹属性、事件和修订记录；生成的视频是按任务采样 FPS 制作的无声复核视频，不是原视频全帧重编码。

名单格式：
```json
[{"player_id":"local-player-1","name":"实际球员姓名","team":"HOU","jersey_number":"7"}]
```

## Agent 接口

所有请求在回环服务执行；POST 使用 `Content-Type: application/json`。

- `GET /api/health`：健康检查。
- `GET /api/inventory`：视频、权重、名单路径。
- `POST /api/jobs`：提交 `game_id, source, model, custom_model, seconds, sample_fps, start, width, team_colors, roster, ocr`。
- `GET /api/jobs/{id}`：完整观察、身份候选、复核原因、事件和审核状态。
- `POST /api/jobs/{id}/review`：人工修订，必须给 `reviewer`。Agent 自动推断不要冒充人工确认。
- `POST /api/jobs/{id}/export`：`{"training":true}` 只导出整帧已审核样本。
- `POST /api/jobs/{id}/render`：生成当前修订版视频。

API 示例：
```json
{"op":"update","id":"0:3","changes":{"team":"DAL","player_id":"actual-player-id"},"reviewer":"审阅者"}
```

## 训练与评测

合并人工确认的导出包。按整场比赛分割，工具拒绝同一 game_id 出现在不同集合：
```bash
python -m nba_assist.cli dataset --archives reviewed_game1.zip reviewed_game2.zip reviewed_game3.zip --splits splits.json --out new_dataset
```
`splits.json` 示例：`{"train":["game1"],"val":["game2"],"test":["game3"]}`。

生成的数据集类别为 `player, ball, rim, referee`，不再把固定五个人姓名当通用球员类别。确认数据量与标注质量后，可在空闲 GPU 时自行训练：
```bash
yolo detect train model=yolo11s.pt data=new_dataset/data.yaml epochs=30 imgsz=960 project=new_training name=reviewed_v1
```

独立人工真值评测：
```bash
python -m nba_assist.cli evaluate --predictions observations.json --truth independent_truth.json --out metrics.json
python -m nba_assist.cli evaluate --events --predictions predicted_events.json --truth independent_events.json --out event_metrics.json
```
检测诊断是固定 IoU 阈值的 precision/recall；身份分开报告覆盖率和已分配身份正确率；轨迹报告已匹配真值上的 ID 切换。它们不是 COCO mAP、HOTA 或 IDF1。没有独立人工真值时不报告准确率。

## 目前边界

- 尚未取得新赛季视频，跨赛季准确率未评测。
- 通用 person 检测会包含裁判、替补和观众；当前需要人工删除或改类，没有自动球场分割门控。
- 场景切换是像素变化启发式；回放/广告需手动标注，没有训练好的场景分类器。
- 自动事件仅支持有足够篮球/篮筐证据时的投篮候选；不保证检测进球，不从身体接触直接判犯规。犯规可从同场逐回合记录导入并人工对齐，或手动标注。
- 颜色直方图检索是弱外观候选，不是训练好的 ReID。新增球员、换球衣、遮挡会降低效果。
- OCR 读取号码不等于身份确认；必须匹配当场名单并有多次独立证据。
- 4090 模型训练成绩不能替代新比赛的独立评测。

## 重启与测试
```bash
cd /root/autodl-tmp/nba/nba-assist
/root/autodl-tmp/nba/nba_assist_runtime/bin/python -m nba_assist.server --root /root/autodl-tmp/nba/nba_assist_data --allowed-root /root/autodl-tmp/nba --port 8768
python -m unittest discover -s tests -v
```
不要重复启动占用同一端口的服务。服务器重启后，旧的进行中任务可能停留在 running；重新提交一个新任务即可，旧预测和修订仍保留。
