"""Example: args = [--data, /workspace/dataset/data.yaml, --model, ...]."""
import argparse,os
from ultralytics import YOLO
p=argparse.ArgumentParser();p.add_argument('--data',required=True);p.add_argument('--model',required=True);p.add_argument('--epochs',type=int,default=30);p.add_argument('--device',default='0');a=p.parse_args()
YOLO(a.model).train(data=a.data,epochs=a.epochs,device=a.device,project=os.environ['NBA_OUTPUT_DIR'],name='train',exist_ok=False)
