"""AWS Batch/SageMaker training submission with the same JSON contract."""
import os,json
from .training import TrainingSpec
def submit_training(spec):
    if not spec.script.startswith('/workspace/') or not spec.workdir.startswith('/workspace') or not spec.output_dir.startswith('/workspace/'):
        raise ValueError('Cloud training script/data must be prepackaged or mounted under /workspace; local paths cannot be sent to AWS')
    if spec.backend=='aws-batch':
        import boto3
        queue=os.environ.get('NBA_BATCH_QUEUE');definition=os.environ.get('NBA_BATCH_JOB_DEFINITION')
        if not queue or not definition:raise ValueError('NBA_BATCH_QUEUE and NBA_BATCH_JOB_DEFINITION are required')
        output=os.environ.get('NBA_TRAINING_S3_OUTPUT','')
        if not output.startswith('s3://'):raise ValueError('NBA_TRAINING_S3_OUTPUT is required')
        r=boto3.client('batch').submit_job(jobName='nba-train-'+spec.job_id,jobQueue=queue,jobDefinition=definition,containerOverrides={'command':['python','-m','nba_assist.training_worker'],'environment':[{'name':'NBA_TRAINING_JSON','value':spec.json()},{'name':'NBA_TRAINING_S3_OUTPUT','value':output}]},retryStrategy={'attempts':int(os.getenv('NBA_BATCH_ATTEMPTS','1'))},timeout={'attemptDurationSeconds':spec.max_seconds})
        return {'job_id':spec.job_id,'status':'submitted','backend':'aws-batch','aws_job_id':r['jobId']}
    import boto3
    role=os.environ.get('NBA_SAGEMAKER_ROLE_ARN');image=os.environ.get('NBA_SAGEMAKER_IMAGE')
    if not role or not image:raise ValueError('NBA_SAGEMAKER_ROLE_ARN and NBA_SAGEMAKER_IMAGE are required')
    name=('nba-train-'+spec.job_id)[:63]
    output=os.environ.get('NBA_TRAINING_S3_OUTPUT','')
    if not output.startswith('s3://'):raise ValueError('NBA_TRAINING_S3_OUTPUT is required')
    r=boto3.client('sagemaker').create_training_job(TrainingJobName=name,RoleArn=role,AlgorithmSpecification={'TrainingImage':image,'TrainingInputMode':'File','ContainerEntrypoint':['python','-m','nba_assist.training_worker']},OutputDataConfig={'S3OutputPath':output},ResourceConfig={'InstanceType':os.getenv('NBA_SAGEMAKER_INSTANCE','ml.g5.xlarge'),'InstanceCount':1,'VolumeSizeInGB':int(os.getenv('NBA_VOLUME_GB','100'))},StoppingCondition={'MaxRuntimeInSeconds':spec.max_seconds},Environment={'NBA_TRAINING_JSON':spec.json(),'NBA_TRAINING_S3_OUTPUT':output})
    return {'job_id':spec.job_id,'status':'submitted','backend':'sagemaker','aws_training_job':r['TrainingJobArn'],'aws_job_name':name}

def cloud_status(receipt):
    import boto3
    if receipt['backend']=='aws-batch':
        jobs=boto3.client('batch').describe_jobs(jobs=[receipt['aws_job_id']])['jobs']
        if not jobs:raise ValueError('AWS job not found')
        j=jobs[0];return {**receipt,'status':j['status'],'detail':j.get('statusReason'),'container':j.get('container',{})}
    j=boto3.client('sagemaker').describe_training_job(TrainingJobName=receipt['aws_job_name'])
    return {**receipt,'status':j['TrainingJobStatus'],'metrics':j.get('FinalMetricDataList',[]),'artifacts':j.get('ModelArtifacts',{}),'detail':j.get('FailureReason')}

def cloud_stop(receipt):
    import boto3
    if receipt['backend']=='aws-batch':boto3.client('batch').terminate_job(jobId=receipt['aws_job_id'],reason='Stopped from NBA Assist')
    else:boto3.client('sagemaker').stop_training_job(TrainingJobName=receipt['aws_job_name'])
    return {**receipt,'stop_requested':True}
