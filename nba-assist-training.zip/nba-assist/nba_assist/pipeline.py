"""Real-video worker; never promotes model predictions to ground truth."""
import hashlib,json,time,os
os.environ.setdefault('YOLO_AUTOINSTALL','false')
from pathlib import Path
from collections import Counter,defaultdict
from types import SimpleNamespace
from .core import class_kind,IdentityResolver,normalize_roster,ShotCandidates,import_events
from .vision import fuse_detections,color_candidate

DEFAULT_ALIASES={'tari_eason':'1631106','jabari_smith':'1631095','kevin_durant':'201142','alperen_sengun':'1630578','amen_thompson':'1641708'}
def atomic_json(path,data):
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8');os.replace(temp,path)
def json_file(path,default):return json.loads(Path(path).read_text(encoding='utf-8-sig')) if path else default
def fingerprint(path):return {'path':str(path),'sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest()}

def run(job_dir):
    import cv2,numpy as np
    import torch
    from ultralytics import YOLO
    from ultralytics.trackers.byte_tracker import BYTETracker
    from ultralytics.engine.results import Boxes
    from .vision import validate_config
    d=Path(job_dir);c=validate_config(json_file(d/'config.json',{}));m=json_file(d/'manifest.json',{})
    m.update(status='running',events=[],frames=[],processed_frames=0,accuracy='NOT_EVALUATED',warnings=[])
    atomic_json(d/'manifest.json',m);started=time.monotonic();(d/'frames').mkdir(exist_ok=True)
    aliases=c.get('aliases',DEFAULT_ALIASES)
    generic=YOLO(c['model']);custom=YOLO(c['custom_model']) if c.get('custom_model') else None
    if not any(str(n).lower() in ('person','player') for n in generic.names.values()):
        raise ValueError('Primary model must include generic person/player; use the six-name model as custom_model')
    m['model_provenance']={'generic':fingerprint(c['model']),'custom':fingerprint(c['custom_model']) if custom else None}
    roster=normalize_roster(c.get('roster',json_file(c.get('roster_path'),[])))
    resolver=IdentityResolver(roster);m['roster']=roster
    gallery=json_file(c.get('gallery_path'),[])
    mapping=c.get('team_colors',{});m['team_colors']=mapping
    reader=None
    if c.get('ocr'):
        import easyocr
        reader=easyocr.Reader(['en'],gpu=False,verbose=False)
    else:m['warnings'].append('Jersey OCR is disabled; names remain detector/appearance candidates unless manually confirmed.')
    if not any(p['jersey_number'] for p in roster):m['warnings'].append('Roster contains no jersey numbers; OCR cannot resolve names automatically.')
    if not mapping:m['warnings'].append('No game-specific jersey-color mapping: team assignment remains unknown.')
    if c.get('pbp_path'):
        pbp=json_file(c['pbp_path'],{});pid=str(pbp.get('game',pbp).get('gameId',''))
        if pid and pid!=str(c['game_id']):raise ValueError('Play-by-play gameId differs from this job game_id')
        m['events']=import_events(pbp)
    cap=cv2.VideoCapture(c['source'])
    if not cap.isOpened():raise ValueError('Cannot decode source video')
    fps=float(cap.get(cv2.CAP_PROP_FPS));total=int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    if not np.isfinite(fps) or fps<=0:raise ValueError('Video has invalid FPS')
    start=float(c.get('start',0));start_frame=round(start*fps)
    if total and start_frame>=total:raise ValueError('Start lies beyond video duration')
    cap.set(cv2.CAP_PROP_POS_FRAMES,start_frame)
    args=SimpleNamespace(track_high_thresh=.25,track_low_thresh=.1,new_track_thresh=.3,track_buffer=30,match_thresh=.8,fuse_score=True)
    stride=max(1,round(fps/c['sample_fps']));effective=fps/stride
    tracker=BYTETracker(args)
    previous=None;shot=0;index=0;frame_number=start_frame;scene_events=ShotCandidates();votes=defaultdict(list)
    m.update(source=c['source'],source_stat={'bytes':Path(c['source']).stat().st_size,'mtime_ns':Path(c['source']).stat().st_mtime_ns},fps=fps,sample_fps=effective,start=start,duration=c['seconds'],scene_gate='human_review_required')
    m['warnings'].append('Generic person detections may include referees, spectators and substitutes. Review the whole frame before training export.')
    def detect(model,img):
        result=model.predict(img,device=c.get('device','0' if torch.cuda.is_available() else 'cpu'),imgsz=int(c.get('imgsz',960)),conf=.12,verbose=False)[0];out=[]
        for box in result.boxes:
            label=str(result.names[int(box.cls.item())]);kind=class_kind(label,aliases)
            score=float(box.conf.item())
            if kind is None or score<(.15 if kind=='ball' else .25):continue
            xy=box.xyxy[0].cpu().tolist()
            if xy[2]<=xy[0] or xy[3]<=xy[1]:continue
            out.append({'kind':kind,'bbox':xy,'confidence':score,'detector_label':label,**({'candidate_player_id':str(aliases[label])} if label in aliases else {})})
        return out
    with (d/'observations.jsonl').open('w',encoding='utf8') as stream:
        try:
            while frame_number/fps<start+c['seconds']:
                ok,img=cap.read()
                if not ok:break
                if (frame_number-start_frame)%stride:
                    frame_number+=1;continue
                scale=min(1,int(c.get('width',1280))/img.shape[1]);img=cv2.resize(img,(round(img.shape[1]*scale),round(img.shape[0]*scale)))
                h,w=img.shape[:2];m.update(width=w,height=h)
                gray=cv2.resize(cv2.cvtColor(img,cv2.COLOR_BGR2GRAY),(64,36))
                cut=previous is not None and float(np.mean(np.abs(gray.astype(float)-previous.astype(float))))>45
                if cut:shot+=1;tracker.reset();scene_events=ShotCandidates()
                previous=gray;t=frame_number/fps
                detections=fuse_detections(detect(generic,img),detect(custom,img) if custom else [])
                players=[r for r in detections if r['kind']=='player']
                arr=np.array([r['bbox']+[r['confidence'],0] for r in players],dtype=np.float32).reshape(-1,6)
                tracks=tracker.update(Boxes(arr,(h,w)),img)
                tracking={int(tr[-1]):(int(tr[4]),tr[:4].tolist()) for tr in tracks}
                player_idx=0;frame_rows=[]
                for j,row in enumerate(detections):
                    row.update(id=f'{index}:{j}',frame=index,source_frame=frame_number,timestamp=t,shot_id=shot,track_id=None,player_id=None,team=None,review_status='unreviewed')
                    row['bbox']=[round(float(x),3) for x in row['bbox']]
                    if row['kind']=='player':
                        tracked=tracking.get(player_idx);player_idx+=1
                        if tracked:row['track_id']=f'{shot}:{tracked[0]}'
                        x1,y1,x2,y2=map(int,row['bbox']);crop=img[max(0,y1):min(h,y2),max(0,x1):min(w,x2)]
                        ch,cw=crop.shape[:2];torso=crop[int(ch*.18):int(ch*.6),int(cw*.2):int(cw*.8)]
                        color=color_candidate(torso);row['color_evidence']=color
                        team=mapping.get(color['color']);key=row['track_id'];team_strength=0.
                        if key and team:
                            votes[key].append(team);recent=votes[key][-20:];winner,n=Counter(recent).most_common(1)[0]
                            if len(recent)>=3 and n/len(recent)>=.8:row['team']=winner;team_strength=.85
                        number=None;number_score=0.;row['ocr_candidates']=[]
                        if reader and ch>=64 and cw>=20 and index%max(1,round(effective/2))==0:
                            roi=crop[int(ch*.15):int(ch*.65)]
                            for poly,text,score in reader.readtext(roi,allowlist='0123456789',detail=1):
                                if text.isdigit() and len(text)<=2:row['ocr_candidates'].append({'text':text,'score':float(score)})
                            if row['ocr_candidates']:
                                best=max(row['ocr_candidates'],key=lambda r:r['score']);number,number_score=best['text'],best['score']
                        row['jersey_number']=number
                        identity=resolver.update(key,t,row['team'],number,min(team_strength,number_score)) if key else {'status':'unknown','player_id':None,'candidates':[]}
                        row['identity_evidence']=identity;row['player_id']=identity['player_id']
                        if row.get('candidate_player_id'):row['name_candidate']={'player_id':row['candidate_player_id'],'score':row['confidence'],'basis':'closed_set_detector'}
                        if torso.size:
                            hist=cv2.calcHist([cv2.cvtColor(torso,cv2.COLOR_BGR2HSV)],[0,1],None,[12,4],[0,180,0,256]).flatten();hist/=max(float(hist.sum()),1)
                            row['appearance_histogram']=hist.tolist();retrieval=[]
                            for g in gallery:
                                gh=g.get('appearance_histogram',[])
                                if len(gh)==len(hist):retrieval.append({'player_id':str(g['player_id']),'score':float(1-np.abs(hist-np.array(gh)).sum()/2),'basis':'color_histogram_not_reid'})
                            row['appearance_candidates']=sorted(retrieval,key=lambda r:r['score'],reverse=True)[:3]
                        reasons=[]
                        if not key:reasons.append('untracked')
                        if row['team'] is None:reasons.append('unknown_team')
                        if identity['status']!='provisional':reasons.append('unknown_identity')
                        if identity.get('conflict'):reasons.append('identity_conflict')
                        row['review_reasons']=reasons
                    frame_rows.append(row);stream.write(json.dumps(row,ensure_ascii=False)+'\n')
                balls=[r for r in frame_rows if r['kind']=='ball'];rims=[r for r in frame_rows if r['kind']=='rim']
                rim=rims[0]['bbox'] if len(rims)==1 else c.get('rim') if c.get('rim_shot',0)==shot else None
                ball=[(balls[0]['bbox'][0]+balls[0]['bbox'][2])/2,(balls[0]['bbox'][1]+balls[0]['bbox'][3])/2] if len(balls)==1 else None
                m['events'].extend(scene_events.update(t,ball,rim,shot))
                file=f'{index:06d}.jpg'
                if not cv2.imwrite(str(d/'frames'/file),img):raise RuntimeError('failed to save review frame')
                m['frames'].append({'index':index,'source_frame':frame_number,'timestamp':t,'file':file,'shot_id':shot,'scene':'unreviewed','scene_cut':cut})
                index+=1;frame_number+=1;stream.flush();m.update(processed_frames=index,elapsed_s=round(time.monotonic()-started,2))
                atomic_json(d/'manifest.json',m)
                if index%10==0:print(f'frames={index} elapsed={m["elapsed_s"]}',flush=True)
        finally:cap.release()
    if not index:raise ValueError('No frames decoded')
    m.update(status='complete',elapsed_s=round(time.monotonic()-started,2))
    if not any(e.get('source')=='visual_rim_crossing' for e in m['events']):m['warnings'].append('No visual shot candidate: rim/ball evidence may be missing. Add event labels manually; this is not proof of no shots.')
    atomic_json(d/'manifest.json',m);print(json.dumps({'status':'complete','frames':index,'elapsed_s':m['elapsed_s']}),flush=True)
