"""Independent-GT diagnostics, not a substitute for COCO mAP or HOTA."""
from .core import iou

def detection_metrics(predictions,truth,threshold=.5):
    remaining=set(range(len(truth)));matched=[]
    for p in sorted(predictions,key=lambda r:r.get('confidence',0),reverse=True):
        candidates=[(iou(p['bbox'],truth[i]['bbox']),i) for i in remaining if p['frame']==truth[i]['frame'] and p['kind']==truth[i]['kind']]
        best=max(candidates,default=(0,None))
        if best[0]>=threshold:
            remaining.remove(best[1]);matched.append((p,truth[best[1]]))
    tp=len(matched);np=len(predictions);nt=len(truth)
    id_gt=[(p,g) for p,g in matched if g.get('player_id') is not None]
    assigned=[(p,g) for p,g in id_gt if p.get('player_id') not in (None,'','unknown')]
    team_gt=[(p,g) for p,g in matched if g.get('team')]
    team_assigned=[(p,g) for p,g in team_gt if p.get('team')]
    history={};switches=0
    for p,g in sorted(matched,key=lambda pair:pair[1]['frame']):
        key=g.get('track_id');pid=p.get('track_id')
        if key is not None and pid is not None:
            if key in history and history[key]!=pid:switches+=1
            history[key]=pid
    return {'tp':tp,'fp':np-tp,'fn':nt-tp,'precision':tp/np if np else None,'recall':tp/nt if nt else None,
            'identity_coverage':len(assigned)/len(id_gt) if id_gt else None,
            'identity_accuracy_when_assigned':sum(str(p['player_id'])==str(g['player_id']) for p,g in assigned)/len(assigned) if assigned else None,
            'team_coverage':len(team_assigned)/len(team_gt) if team_gt else None,
            'team_accuracy_when_assigned':sum(p['team']==g['team'] for p,g in team_assigned)/len(team_assigned) if team_assigned else None,
            'track_id_switches_on_matched_gt':switches,'iou_threshold':threshold,
            'note':'Greedy IoU diagnostic; not mAP/HOTA/IDF1. Evaluate complete independently annotated frames only.'}

def event_metrics(predictions,truth,tolerance=1.):
    predictions=[p for p in predictions if p.get('start') is not None]
    truth=[g for g in truth if g.get('start') is not None]
    available=set(range(len(truth)));tp=0
    for p in sorted(predictions,key=lambda p:p['start']):
        matches=[(abs(p['start']-truth[i]['start']),i) for i in available if p['kind']==truth[i]['kind']]
        d,i=min(matches,default=(float('inf'),None))
        if d<=tolerance:available.remove(i);tp+=1
    precision=tp/len(predictions) if predictions else None;recall=tp/len(truth) if truth else None
    return {'precision':precision,'recall':recall,'tp':tp,'fp':len(predictions)-tp,'fn':len(truth)-tp,
            'f1':2*precision*recall/(precision+recall) if precision is not None and recall is not None and precision+recall else 0 if truth else None,
            'tolerance_seconds':tolerance}
