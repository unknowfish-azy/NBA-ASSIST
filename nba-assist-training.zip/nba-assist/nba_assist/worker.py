import argparse,json
from pathlib import Path
from .vision import run_ultralytics,validate_config

def main():
    p=argparse.ArgumentParser();p.add_argument('--config');p.add_argument('--out');p.add_argument('--model');p.add_argument('--job');a=p.parse_args()
    if a.job:
        from .pipeline import run
        run(a.job);return
    c=validate_config(json.loads(Path(a.config).read_text(encoding='utf8')));rows=run_ultralytics(c['source'],a.model,a.out,c['seconds'],c['sample_fps'],c.get('width',960),c.get('aliases',{}));print(json.dumps({'status':'ok','observations':len(rows),'out':a.out},ensure_ascii=False))
if __name__=='__main__':main()
