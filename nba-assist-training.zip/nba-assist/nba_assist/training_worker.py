import json,os,sys,time,subprocess,signal,argparse
from pathlib import Path
from .training import TrainingSpec,write_status
def supervise(job):
    spec=TrainingSpec(**json.loads((job/'spec.json').read_text(encoding='utf8')))
    executable=json.loads((job/'runner.json').read_text(encoding='utf8'))['python']
    status=json.loads((job/'status.json').read_text(encoding='utf8'));started=time.monotonic()
    env={**os.environ,**spec.env,'NBA_OUTPUT_DIR':spec.output_dir,'NBA_TRAINING_JOB_ID':spec.job_id,'PYTHONUNBUFFERED':'1'}
    try:
        with (job/'train.log').open('w',encoding='utf8') as log:
            proc=subprocess.Popen([executable,'-u',spec.script,*spec.args],cwd=spec.workdir,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=os.name!='nt',creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
            status.update(status='running',pid=proc.pid,started_at=time.time());write_status(job,status)
            stopped=None
            while proc.poll() is None:
                if (job/'cancel').exists() or time.monotonic()-started>spec.max_seconds:
                    stopped='stopped' if (job/'cancel').exists() else 'timed_out'
                    if os.name=='nt':subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],capture_output=True)
                    else:os.killpg(proc.pid,signal.SIGTERM)
                    try:proc.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        if os.name!='nt':os.killpg(proc.pid,signal.SIGKILL)
                        else:proc.kill()
                    break
                time.sleep(.2)
            code=proc.wait();status.update(status=stopped or ('completed' if code==0 else 'failed'),exit_code=code,finished_at=time.time())
    except Exception as e:status.update(status='failed',error=str(e),finished_at=time.time())
    write_status(job,status);return status
def main():
    p=argparse.ArgumentParser();p.add_argument('--job');a=p.parse_args()
    if a.job:result=supervise(Path(a.job))
    else:
        spec=TrainingSpec(**json.loads(os.environ['NBA_TRAINING_JSON']))
        from .training import validate_spec
        validate_spec(spec,os.getenv('NBA_TRAINING_ROOT','/workspace'))
        job=Path('/tmp')/('nba-train-'+spec.job_id);job.mkdir(exist_ok=False);Path(spec.output_dir).mkdir(parents=True,exist_ok=True)
        (job/'spec.json').write_text(spec.json(),encoding='utf8');(job/'runner.json').write_text(json.dumps({'python':sys.executable}));write_status(job,{'id':spec.job_id,'status':'queued'})
        result=supervise(job)
        if os.getenv('NBA_TRAINING_S3_OUTPUT'):
            from .cloud import S3Store
            from urllib.parse import urlparse
            u=urlparse(os.environ['NBA_TRAINING_S3_OUTPUT']);store=S3Store(u.netloc,u.path.strip('/')+'/'+spec.job_id)
            out=Path(spec.output_dir)
            for f in out.rglob('*'):
                if f.is_file() and f.resolve().is_relative_to(out.resolve()):store.put_file(f.relative_to(out).as_posix(),f)
            store.put_file('train.log',job/'train.log');store.put_bytes('status.json',json.dumps(result).encode())
    print(json.dumps(result),flush=True)
    if result['status']!='completed':sys.exit(1)
if __name__=='__main__':main()
