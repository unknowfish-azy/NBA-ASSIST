"""Portable worker: materialize inputs, run inference, publish review bundle."""
import argparse,json,os,shutil,zipfile,tempfile
from pathlib import Path
from urllib.parse import urlparse,unquote
from .cloud import JobSpec,S3Store,content_sha256

def fetch(uri,target):
    target=Path(target);target.parent.mkdir(parents=True,exist_ok=True)
    if uri.startswith('s3://'):
        u=urlparse(uri);store=S3Store(u.netloc);store.client.download_file(u.netloc,u.path.lstrip('/'),str(target))
    else:
        source=Path(unquote(urlparse(uri).path)) if uri.startswith('file://') else Path(uri)
        shutil.copyfile(source,target)
    return target

def stage(spec,root):
    p=Path(root)/spec.id;p.mkdir(parents=True,exist_ok=False)
    assets=p/'inputs';assets.mkdir()
    video=fetch(spec.input_uri,assets/'video.mp4');model=fetch(spec.model_uri,assets/'model.pt')
    c={'id':spec.id,'game_id':spec.game_id,'source':str(video.resolve()),'model':str(model.resolve()),
       'seconds':spec.seconds,'sample_fps':spec.sample_fps,'start':spec.start,'width':spec.width,
       'input_sha256':content_sha256(video),'model_sha256':content_sha256(model),**spec.options}
    if spec.custom_model_uri:c['custom_model']=str(fetch(spec.custom_model_uri,assets/'custom.pt').resolve())
    (p/'config.json').write_text(json.dumps(c),encoding='utf8')
    (p/'job.json').write_text(spec.json(),encoding='utf8')
    (p/'manifest.json').write_text(json.dumps({'id':spec.id,'game_id':spec.game_id,'status':'queued','source':spec.input_uri,'frames':[]}),encoding='utf8')
    return p

def publish(p,spec):
    bundle=p/'result.zip'
    with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as z:
        for f in p.rglob('*'):
            if f.is_file() and f!=bundle and 'inputs' not in f.relative_to(p).parts:z.write(f,f.relative_to(p).as_posix())
    if spec.output_uri.startswith('s3://'):
        u=urlparse(spec.output_uri);store=S3Store(u.netloc,u.path.strip('/'))
        store.put_file(spec.id+'/result.zip',bundle)
        return store.uri(spec.id+'/result.zip')
    target=Path(spec.output_uri)/spec.id;target.mkdir(parents=True,exist_ok=True);shutil.copy2(bundle,target/'result.zip');return str(target/'result.zip')

def restore(archive,target):
    target=Path(target).resolve()
    if target.exists():raise ValueError('restore destination already exists')
    with zipfile.ZipFile(archive) as z:
        for info in z.infolist():
            name=info.filename.replace('\\','/')
            if not (target/name).resolve().is_relative_to(target) or name.startswith('/') or ':' in name:raise ValueError('unsafe archive path')
            if (info.external_attr>>16)&0o170000==0o120000:raise ValueError('symlink in archive')
        z.extractall(target)
    return target

def run_spec(spec,root):
    p=stage(spec,root)
    try:
        from .pipeline import run
        run(p)
    except Exception as e:
        m=json.loads((p/'manifest.json').read_text());m.update(status='failed',error=str(e));(p/'manifest.json').write_text(json.dumps(m),encoding='utf8');publish(p,spec);raise
    return publish(p,spec)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--spec');parser.add_argument('--root',default=os.getenv('NBA_WORK_ROOT','/tmp/nba-assist'));a=parser.parse_args()
    data=json.loads(Path(a.spec).read_text(encoding='utf8')) if a.spec else json.loads(os.environ['NBA_JOB_JSON'])
    print(json.dumps({'result_uri':run_spec(JobSpec(**data),a.root)}),flush=True)
if __name__=='__main__':main()
