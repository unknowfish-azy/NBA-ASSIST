"""Pure contracts: identity evidence, review revisions, and event candidates."""
import copy
import math
from collections import defaultdict

KINDS = ('player', 'ball', 'rim', 'referee')
EVENT_KINDS = ('shot', 'made_shot', 'missed_shot', 'foul', 'rebound', 'turnover', 'other')

def class_kind(name, aliases):
    name = str(name).lower().strip()
    if name in ('person', 'player') or name in aliases: return 'player'
    if name in ('basketball', 'sports ball', 'ball'): return 'ball'
    if name in ('hoop', 'rim', 'basket'): return 'rim'
    if name == 'referee': return 'referee'
    return None

def normalize_roster(raw):
    rows = raw.get('players', []) if isinstance(raw, dict) else raw
    if not isinstance(rows, list): raise ValueError('roster must be a list or an object with players')
    out=[]
    for p in rows:
        pid=p.get('player_id'); number=p.get('jersey_number',p.get('jersey'))
        if pid in (None,''): raise ValueError('each roster player needs player_id')
        out.append({**p,'player_id':str(pid),'jersey_number':None if number in (None,'') else str(number)})
    if len({p['player_id'] for p in out})!=len(out): raise ValueError('duplicate player_id')
    return out

class IdentityResolver:
    """Three separated team+number observations; scores are uncalibrated."""
    def __init__(self, roster):
        self.roster=normalize_roster(roster); self.votes=defaultdict(list)
    def update(self, key, timestamp, team, number, score):
        votes=self.votes[key]
        matches=[p for p in self.roster if team and number is not None and p.get('team')==team and p['jersey_number']==str(number)]
        if len(matches)==1 and score>=.8 and all(abs(timestamp-v[0])>=.5 for v in votes):
            votes.append((timestamp,matches[0]['player_id']))
        ids={v[1] for v in votes}
        pid=next(iter(ids)) if len(ids)==1 and len(votes)>=3 else None
        return {'player_id':pid,'status':'provisional' if pid else 'unknown',
                'independent_observations':len(votes),'conflict':len(ids)>1,
                'candidates':sorted(ids),'score_calibrated':False}

def box_checked(box,width,height):
    if not isinstance(box,(list,tuple)) or len(box)!=4: raise ValueError('bbox requires x1,y1,x2,y2')
    x1,y1,x2,y2=map(float,box)
    if not all(math.isfinite(v) for v in (x1,y1,x2,y2)): raise ValueError('nonfinite bbox')
    if not (0<=x1<x2<=width and 0<=y1<y2<=height): raise ValueError('bbox outside image or empty')
    return [round(v,3) for v in (x1,y1,x2,y2)]

EDIT_FIELDS={'bbox','team','player_id','jersey_number','track_id','kind'}
def reduce_reviews(observations, revisions, width, height):
    rows=copy.deepcopy(observations)
    for edit in revisions:
        op=edit['op']
        if op in ('approve_frame','event','scene'): continue
        if op=='add':
            row=copy.deepcopy(edit['observation'])
            if any(r['id']==row['id'] for r in rows): raise ValueError('duplicate observation id')
            row['bbox']=box_checked(row['bbox'],width,height)
            if row.get('kind') not in KINDS: raise ValueError('invalid object kind')
            row['review_status']='human_confirmed';rows.append(row);continue
        if op not in ('update','delete','track'): raise ValueError('unsupported review operation')
        changes=edit.get('changes',{})
        if set(changes)-EDIT_FIELDS: raise ValueError('unsupported observation field')
        if 'kind' in changes and changes['kind'] not in KINDS: raise ValueError('invalid object kind')
        if 'bbox' in changes: changes={**changes,'bbox':box_checked(changes['bbox'],width,height)}
        matches=[]
        for row in rows:
            match=(row['id']==edit.get('id')) if op!='track' else (
                row.get('track_id')==edit['track_id'] and row['shot_id']==edit['shot_id'] and
                edit['start_frame']<=row['frame']<=edit['end_frame'])
            if match: matches.append(row)
        if not matches: raise ValueError('review target not found')
        if op=='delete': rows=[r for r in rows if r not in matches]
        else:
            for row in matches:
                row.update(copy.deepcopy(changes));row['review_status']='human_confirmed'
                row['reviewer']=edit.get('reviewer');row['revision_id']=edit.get('revision_id')
    return rows

def approved_frames(revisions):
    approved=set()
    for e in revisions:
        if e['op']=='approve_frame': approved.add(e['frame'])
        elif e['op']=='track':
            approved={f for f in approved if not e['start_frame']<=f<=e['end_frame']}
        elif e['op'] in ('update','add','delete','scene'): approved.discard(e.get('frame'))
    return approved

def import_events(raw):
    rows=raw.get('game',raw).get('actions',[]) if isinstance(raw,dict) else raw
    out=[]
    for i,row in enumerate(rows):
        a=str(row.get('actionType','')).lower(); result=row.get('shotResult')
        kind=('foul' if 'foul' in a else 'made_shot' if result=='Made' else
              'missed_shot' if result=='Missed' else 'rebound' if 'rebound' in a else
              'turnover' if 'turnover' in a else None)
        if kind:
            out.append({'id':'pbp-'+str(i),'kind':kind,'start':None,'end':None,'status':'unaligned',
                        'source':'official_record_import','game_clock':row.get('clock'),
                        'period':row.get('period'),'player_id':str(row.get('personId','')),
                        'team':row.get('teamTricode'),'description':row.get('description',''),
                        'action_id':row.get('actionId'),'game_id':raw.get('game',raw).get('gameId') if isinstance(raw,dict) else None})
    return out

def merge_event(old, new):
    """Apply a human event revision without dropping imported evidence."""
    if old is None: return dict(new)
    merged=dict(old);merged.update(new)
    if isinstance(old.get('evidence'),dict) or isinstance(new.get('evidence'),dict):
        evidence=dict(old.get('evidence') or {});evidence.update(new.get('evidence') or {});merged['evidence']=evidence
    return merged

class ShotCandidates:
    """A 2-D rim crossing is a review cue, never proof of a made basket."""
    def __init__(self): self.previous=None;self.last_event=-10
    def update(self,t,ball,rim,shot):
        old=self.previous;self.previous=(t,ball,shot) if ball is not None and rim is not None else None
        if not old or not self.previous or old[2]!=shot or not 0<t-old[0]<=.25: return []
        x1,y1,x2,y2=rim
        if old[1][1]<y1<=ball[1] and x1<=ball[0]<=x2 and t-self.last_event>2:
            self.last_event=t
            return [{'id':f'visual-{shot}-{t:.3f}','kind':'shot','start':max(0,t-2),'end':t+1,
                     'status':'candidate','source':'visual_rim_crossing','description':'2D rim crossing; verify shot and outcome'}]
        return []

def iou(a,b):
    inter=max(0,min(a[2],b[2])-max(a[0],b[0]))*max(0,min(a[3],b[3])-max(a[1],b[1]))
    union=(a[2]-a[0])*(a[3]-a[1])+(b[2]-b[0])*(b[3]-b[1])-inter
    return inter/union if union>0 else 0.
