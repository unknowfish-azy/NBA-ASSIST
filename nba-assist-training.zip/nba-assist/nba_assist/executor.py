"""Submit the same immutable JobSpec locally or to AWS without embedding credentials."""
import json,os,subprocess
from pathlib import Path
from .cloud import JobSpec

def submit_local(spec,root='data'):
    from .cloud_runtime import run_spec
    return {'executor':'local','job_id':spec.id,'result_uri':run_spec(spec,Path(root)/'jobs')}
def submit_batch(spec):
    try:import boto3
    except ImportError as e:raise RuntimeError('Install boto3 to use AWS Batch') from e
    queue=os.environ.get('NBA_BATCH_QUEUE');definition=os.environ.get('NBA_BATCH_JOB_DEFINITION')
    if not queue or not definition:raise ValueError('NBA_BATCH_QUEUE and NBA_BATCH_JOB_DEFINITION are required')
    r=boto3.client('batch').submit_job(jobName='nba-assist-'+spec.id,jobQueue=queue,jobDefinition=definition,containerOverrides={'command':['python','-m','nba_assist.cloud_runtime'],'environment':[{'name':'NBA_JOB_JSON','value':spec.json()}]},retryStrategy={'attempts':int(os.getenv('NBA_BATCH_ATTEMPTS','1'))},timeout={'attemptDurationSeconds':int(os.getenv('NBA_MAX_SECONDS','7200'))})
    return {'executor':'aws-batch','job_id':spec.id,'aws_job_id':r['jobId']}
def submit_sagemaker(spec):
    try:import boto3
    except ImportError as e:raise RuntimeError('Install boto3 to use SageMaker') from e
    name=os.environ.get('NBA_SAGEMAKER_TRAINING_JOB','nba-assist');role=os.environ.get('NBA_SAGEMAKER_ROLE_ARN');image=os.environ.get('NBA_SAGEMAKER_IMAGE')
    if not name or not role or not image:raise ValueError('NBA_SAGEMAKER_TRAINING_JOB, ROLE_ARN and IMAGE are required')
    job_name=(name+'-'+spec.id)[:63]
    r=boto3.client('sagemaker').create_training_job(TrainingJobName=job_name,RoleArn=role,AlgorithmSpecification={'TrainingImage':image,'TrainingInputMode':'File','ContainerEntrypoint':['python','-m','nba_assist.cloud_runtime']},OutputDataConfig={'S3OutputPath':spec.output_uri},ResourceConfig={'InstanceType':os.getenv('NBA_SAGEMAKER_INSTANCE','ml.g5.xlarge'),'InstanceCount':1,'VolumeSizeInGB':int(os.getenv('NBA_VOLUME_GB','100'))},StoppingCondition={'MaxRuntimeInSeconds':int(os.getenv('NBA_MAX_SECONDS','7200'))},Environment={'NBA_JOB_JSON':spec.json()})
    return {'executor':'sagemaker','job_id':spec.id,'aws_training_job':r['TrainingJobArn'],'aws_job_name':job_name}
def submit(spec,root='data'):
    return submit_local(spec,root) if spec.executor=='local' else submit_batch(spec) if spec.executor=='aws-batch' else submit_sagemaker(spec)

def monitor(receipt):
    import boto3
    if receipt['executor']=='aws-batch':return boto3.client('batch').describe_jobs(jobs=[receipt['aws_job_id']])['jobs']
    if receipt['executor']=='sagemaker':return boto3.client('sagemaker').describe_training_job(TrainingJobName=receipt['aws_job_name'])
    return receipt
