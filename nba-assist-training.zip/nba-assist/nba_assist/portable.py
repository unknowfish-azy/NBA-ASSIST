"""python -m nba_assist.portable prepare/submit/monitor/review."""
import argparse,json,os,tempfile
from pathlib import Path
from .cloud import JobSpec,make_store,content_sha256
from .executor import submit,monitor
from .cloud_runtime import fetch,restore

def main():
    p=argparse.ArgumentParser();sub=p.add_subparsers(dest='cmd',required=True)
    a=sub.add_parser('prepare');a.add_argument('--video',required=True);a.add_argument('--model',required=True);a.add_argument('--custom-model');a.add_argument('--game-id',required=True);a.add_argument('--out',required=True);a.add_argument('--storage-root',default='data/objects');a.add_argument('--executor',default=os.getenv('NBA_EXECUTOR','local'));a.add_argument('--seconds',type=float,default=30);a.add_argument('--fps',type=float,default=10);a.add_argument('--options',help='JSON with roster, team_colors, device and/or ocr')
    a=sub.add_parser('submit');a.add_argument('--spec',required=True);a.add_argument('--receipt',required=True);a.add_argument('--root',default='data')
    a=sub.add_parser('monitor');a.add_argument('--receipt',required=True)
    a=sub.add_parser('train');a.add_argument('--script',required=True);a.add_argument('--game-id',required=True);a.add_argument('--workdir',required=True);a.add_argument('--output-dir',required=True);a.add_argument('--args',nargs='*',default=[]);a.add_argument('--backend',default=os.getenv('NBA_TRAINING_BACKEND','local'));a.add_argument('--root',default='data');a.add_argument('--max-seconds',type=int,default=7200)
    a=sub.add_parser('train-status');a.add_argument('--job-id',required=True);a.add_argument('--root',default='data')
    a=sub.add_parser('train-stop');a.add_argument('--job-id',required=True);a.add_argument('--root',default='data')
    a=sub.add_parser('review');a.add_argument('--result',required=True);a.add_argument('--root',default='data');a.add_argument('--job-id',required=True)
    a=p.parse_args()
    if a.cmd=='train':
        from .training import TrainingSpec,run_local
        s=TrainingSpec(a.game_id,a.script,a.args,a.workdir,a.output_dir,backend=a.backend,max_seconds=a.max_seconds)
        if a.backend=='local':r=run_local(s,a.root)
        else:
            from .training_cloud import submit_training;r=submit_training(s)
        print(json.dumps(r));return
    if a.cmd in ('train-status','train-stop'):
        from .training import refresh,stop
        print(json.dumps((refresh if a.cmd=='train-status' else stop)(a.root,a.job_id)));return
    if a.cmd=='prepare':
        store=make_store(a.storage_root)
        def put(path):
            key='assets/'+content_sha256(path)+Path(path).suffix.lower();store.put_file(key,path);return store.uri(key)
        options=json.loads(Path(a.options).read_text(encoding='utf8')) if a.options else {}
        spec=JobSpec(a.game_id,put(a.video),put(a.model),store.uri('results'),executor=a.executor,custom_model_uri=put(a.custom_model) if a.custom_model else None,seconds=a.seconds,sample_fps=a.fps,options=options)
        # Local outputs use a native path; no file URI interpretation needed by publisher.
        if spec.output_uri.startswith('file://'):object.__setattr__(spec,'output_uri',str(store.path('results')))
        Path(a.out).write_text(spec.json(),encoding='utf8');print(spec.json())
    elif a.cmd=='submit':
        r=submit(JobSpec(**json.loads(Path(a.spec).read_text(encoding='utf8'))),a.root);Path(a.receipt).write_text(json.dumps(r,indent=2),encoding='utf8');print(json.dumps(r))
    elif a.cmd=='monitor':print(json.dumps(monitor(json.loads(Path(a.receipt).read_text(encoding='utf8'))),default=str))
    else:
        import re
        if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',a.job_id):raise ValueError('invalid job ID')
        with tempfile.TemporaryDirectory() as tmp:
            archive=fetch(a.result,Path(tmp)/'result.zip');target=restore(archive,Path(a.root)/'jobs'/a.job_id)
            m=json.loads((target/'manifest.json').read_text(encoding='utf8'));m['id']=a.job_id;(target/'manifest.json').write_text(json.dumps(m),encoding='utf8')
        print('Ready for local review: '+str(target))
if __name__=='__main__':main()
