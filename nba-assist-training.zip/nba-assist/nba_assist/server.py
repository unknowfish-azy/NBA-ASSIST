"""Loopback-only review API. Inference runs serially in child processes."""
import argparse,json,mimetypes,re,sqlite3,subprocess,sys,threading,time,uuid,os
from contextlib import closing
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from urllib.parse import urlparse,unquote
from .core import reduce_reviews,approved_frames,normalize_roster,EVENT_KINDS,merge_event
from .export import make_export,merged_events
from .vision import validate_config

def read_json(path,default=None):
    return json.loads(Path(path).read_text(encoding='utf8')) if Path(path).exists() else default

class Application:
    def __init__(self,root,allowed_root):
        self.root=Path(root).resolve();self.allowed_root=Path(allowed_root).resolve()
        self.jobs=self.root/'jobs';self.jobs.mkdir(parents=True,exist_ok=True)
        (self.root/'uploads').mkdir(exist_ok=True)
        self.lock=threading.RLock();self.gpu_lock=threading.Lock()
        self.db=self.root/'reviews.sqlite3'
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('CREATE TABLE IF NOT EXISTS revisions (sequence INTEGER PRIMARY KEY AUTOINCREMENT,job TEXT NOT NULL,body TEXT NOT NULL)')
    def allowed_path(self,value):
        p=Path(value).resolve()
        if not any(p.is_relative_to(root) for root in (self.allowed_root,self.root)):raise ValueError('path outside allowed project root')
        return p
    def job_dir(self,job_id):
        if not re.fullmatch(r'[A-Za-z0-9_-]{1,80}',job_id):raise ValueError('invalid job id')
        p=self.jobs/job_id
        if not p.is_dir():raise ValueError('job not found')
        return p
    def revisions(self,job_id):
        with closing(sqlite3.connect(self.db)) as db:return [json.loads(row[0]) for row in db.execute('SELECT body FROM revisions WHERE job=? ORDER BY sequence',(job_id,))]
    def state(self,job_id):
        p=self.job_dir(job_id);job=read_json(p/'manifest.json',{})
        rows=[]
        if (p/'observations.jsonl').exists():
            for line in (p/'observations.jsonl').read_text(encoding='utf8').splitlines():
                try: rows.append(json.loads(line))
                except json.JSONDecodeError: pass  # partial last record during a running job
        revisions=self.revisions(job_id)
        corrected=reduce_reviews(rows,revisions,job.get('width',1),job.get('height',1))
        scenes={str(e['frame']):e['scene'] for e in revisions if e['op']=='scene'}
        return {**job,'observations':corrected,'events':merged_events(job.get('events',[]),revisions),
                'approved_frames':sorted(approved_frames(revisions)),'scenes':scenes,'revision_count':len(revisions)}
    def list_jobs(self):
        rows=[]
        for p in self.jobs.glob('*/manifest.json'):
            m=read_json(p,{});rows.append({k:m.get(k) for k in ('id','game_id','status','error','processed_frames','created_at','source','elapsed_s')})
        return sorted(rows,key=lambda r:r.get('created_at') or '',reverse=True)
    def training_jobs(self):
        from .training import refresh
        root=self.root
        p=root/'training_jobs';p.mkdir(exist_ok=True)
        return [refresh(root,x.name) for x in p.iterdir() if x.is_dir() and re.fullmatch(r'[A-Za-z0-9_-]{1,64}',x.name)]
    def create_training(self,body):
        from .training import TrainingSpec,run_local,validate_spec
        backend=body.get('backend',os.getenv('NBA_TRAINING_BACKEND','local'))
        spec=TrainingSpec(body.get('game_id','training'),body['script'],body.get('args',[]),body.get('workdir',str(self.allowed_root)),body.get('output_dir',str(self.allowed_root/'training_outputs'/uuid.uuid4().hex[:12])),backend=backend,env=body.get('env',{}),max_seconds=int(body.get('max_seconds',7200)),job_id=body.get('job_id',''))
        if backend!='local':
            from .training_cloud import submit_training
            receipt=submit_training(spec);p=self.root/'training_jobs'/spec.job_id;p.mkdir(parents=True,exist_ok=False)
            (p/'spec.json').write_text(spec.json(),encoding='utf8');(p/'cloud_receipt.json').write_text(json.dumps(receipt),encoding='utf8');(p/'status.json').write_text(json.dumps(receipt),encoding='utf8');return receipt
        return run_local(spec,self.root,allowed_root=self.allowed_root)
    def inventory(self):
        videos=[];models=[];rosters=[]
        for p in self.allowed_root.rglob('*'):
            if not p.is_file():continue
            if any(part in ('nba_assist_runtime','.git','node_modules') for part in p.parts):continue
            s=p.suffix.lower()
            if s in ('.mp4','.mkv','.mov','.avi'):videos.append(str(p))
            if s=='.pt':models.append(str(p))
            if s=='.json' and 'roster' in p.name.lower():rosters.append(str(p))
        return {'videos':videos[:100],'models':models[:100],'rosters':rosters[:100], 'allowed_root':str(self.allowed_root)}
    def create_job(self,c):
        c=validate_config(c)
        for key in ('source','model','custom_model','roster_path','pbp_path','gallery_path'):
            if c.get(key):
                c[key]=str(self.allowed_path(c[key]))
                if not Path(c[key]).is_file():raise ValueError(key+' file not found')
        if not c.get('model'):raise ValueError('generic model path required')
        if float(c.get('start',0))<0:raise ValueError('start must be nonnegative')
        if 'roster' in c:c['roster']=normalize_roster(c['roster'])
        job_id=uuid.uuid4().hex[:16];p=self.jobs/job_id;p.mkdir()
        c['id']=job_id
        (p/'config.json').write_text(json.dumps(c,ensure_ascii=False,indent=2),encoding='utf8')
        manifest={'id':job_id,'game_id':c['game_id'],'status':'queued','source':c['source'],'created_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'frames':[]}
        (p/'manifest.json').write_text(json.dumps(manifest),encoding='utf8')
        threading.Thread(target=self.run_job,args=(p,),daemon=True).start()
        return manifest
    def run_job(self,p):
        with self.gpu_lock:
            try:
                backend=os.getenv('NBA_EXECUTOR','local')
                if backend not in ('local','aws-batch','sagemaker'):raise ValueError('unsupported NBA_EXECUTOR')
                if backend!='local':
                    from .cloud_bridge import execute_cloud
                    execute_cloud(p);return
                with (p/'worker.log').open('w',encoding='utf8') as log:
                    completed=subprocess.run([sys.executable,'-m','nba_assist.worker','--job',str(p)],cwd=str(Path(__file__).resolve().parent.parent),stdout=log,stderr=log)
                if completed.returncode:
                    m=read_json(p/'manifest.json',{});m.update(status='failed',error=(p/'worker.log').read_text(encoding='utf8',errors='replace')[-2500:]);(p/'manifest.json').write_text(json.dumps(m),encoding='utf8')
                else:
                    from .cloud_bridge import mirror_local_result
                    try:mirror_local_result(p)
                    except Exception as e:
                        m=read_json(p/'manifest.json',{});m.setdefault('warnings',[]).append('Inference complete but S3 synchronization failed: '+str(e));(p/'manifest.json').write_text(json.dumps(m),encoding='utf8')
            except Exception as e:
                m=read_json(p/'manifest.json',{});m.update(status='failed',error=str(e));(p/'manifest.json').write_text(json.dumps(m),encoding='utf8')
    def review(self,job_id,edit):
        with self.lock:
            state=self.state(job_id)
            if state.get('status')!='complete':raise ValueError('wait for inference completion before review')
            if not str(edit.get('reviewer','')).strip():raise ValueError('reviewer is required')
            edit=dict(edit,revision_id=uuid.uuid4().hex,reviewed_at=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
            frames={f['index']:f for f in state['frames']};op=edit.get('op')
            if op in ('update','delete'):
                row=next((r for r in state['observations'] if r['id']==edit.get('id')),None)
                if row is None:raise ValueError('observation not found')
                edit['frame']=row['frame']
            if op=='add':
                f=frames.get(edit.get('frame'))
                if not f:raise ValueError('unknown frame')
                edit['observation']={**edit.get('observation',{}),'id':'human-'+uuid.uuid4().hex[:12], 'frame':f['index'],'shot_id':f['shot_id'],'timestamp':f['timestamp']}
            if op in ('approve_frame','scene','add') and edit.get('frame') not in frames:raise ValueError('unknown frame')
            if op=='scene' and edit.get('scene') not in ('game_wide','closeup','replay','ad_graphic','transition','other'):raise ValueError('unknown scene')
            if op=='track':
                start=edit.get('start_frame');end=edit.get('end_frame')
                if not isinstance(start,int) or not isinstance(end,int) or start>end:raise ValueError('invalid track interval')
            if op=='event':
                e=edit.get('event',{})
                if e.get('kind') not in EVENT_KINDS:raise ValueError('unknown event kind')
                start=e.get('start');end=e.get('end')
                if e.get('status')=='rejected' and start in (None,'') and end in (None,''):
                    edit['event']={**e,'id':e.get('id') or 'human-event-'+uuid.uuid4().hex[:12],'start':None,'end':None,'reviewer':edit['reviewer']}
                    with closing(sqlite3.connect(self.db)) as db:
                        db.execute('INSERT INTO revisions(job,body) VALUES(?,?)',(job_id,json.dumps(edit,ensure_ascii=False)));db.commit()
                    return {'ok':True,'revision_id':edit['revision_id']}
                start=float(start);end=float(end)
                lower=min((f['timestamp'] for f in state['frames']),default=0)
                upper=max((f['timestamp'] for f in state['frames']),default=0)+1/max(state.get('sample_fps',1),.001)
                if not lower<=start<=end<=upper:raise ValueError('event must lie inside processed video interval')
                if e.get('status') not in ('human_confirmed','rejected','candidate'):raise ValueError('invalid event status')
                edit['event']={**e,'id':e.get('id') or 'human-event-'+uuid.uuid4().hex[:12],'start':start,'end':end,'reviewer':edit['reviewer']}
            reduce_reviews(state['observations'],[edit],state['width'],state['height'])
            with closing(sqlite3.connect(self.db)) as db:
                db.execute('INSERT INTO revisions(job,body) VALUES(?,?)',(job_id,json.dumps(edit,ensure_ascii=False)));db.commit()
            return {'ok':True,'revision_id':edit['revision_id']}
    def export(self,job_id,training):
        with self.lock:
            p=self.job_dir(job_id);m=read_json(p/'manifest.json')
            if m.get('status')!='complete':raise ValueError('job not complete')
            rows=[json.loads(line) for line in (p/'observations.jsonl').read_text(encoding='utf8').splitlines() if line.strip()]
            target=make_export(p,m,rows,self.revisions(job_id),m.get('events',[]),training)
            return {'url':f'/files/{job_id}/{target.name}'}

def make_server(app,port=8768,host='127.0.0.1'):
    web=Path(__file__).resolve().parent.parent/'web'
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def send_json(self,obj,code=200):
            data=json.dumps(obj,ensure_ascii=False).encode();self.send_response(code);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(data)
        def file(self,path):
            if not path.is_file():return self.send_json({'error':'not found'},404)
            self.send_response(200);self.send_header('Content-Type',mimetypes.guess_type(str(path))[0] or 'application/octet-stream');self.send_header('Content-Length',str(path.stat().st_size));self.send_header('X-Content-Type-Options','nosniff');self.end_headers()
            with path.open('rb') as f:
                while data:=f.read(1024*1024):self.wfile.write(data)
        def do_GET(self):
            try:
                path=unquote(urlparse(self.path).path);parts=path.strip('/').split('/')
                if path=='/':return self.file(web/'review.html')
                if path=='/training':return self.file(web/'training.html')
                if path in ('/app.js','/style.css'):return self.file(web/path[1:])
                if path=='/api/health':return self.send_json({'status':'ok','version':'1.1','binding':host,'executor':os.getenv('NBA_EXECUTOR','local'),'storage':os.getenv('NBA_STORAGE','local')})
                if path=='/api/inventory':return self.send_json(app.inventory())
                if path=='/api/jobs':return self.send_json(app.list_jobs())
                if path=='/api/training':return self.send_json(app.training_jobs())
                if len(parts)==3 and parts[:2]==['api','training']:
                    from .training import refresh
                    return self.send_json(refresh(app.root,parts[2]))
                if len(parts)>=3 and parts[0]=='training-files':
                    from .training import job_path
                    job=job_path(app.root,parts[1]);spec=read_json(job/'spec.json');root=Path(spec['output_dir']).resolve()
                    target=(root/'/'.join(parts[2:])).resolve()
                    if not target.is_relative_to(root):raise ValueError('artifact outside output directory')
                    return self.file(target)
                if len(parts)==3 and parts[:2]==['api','jobs']:return self.send_json(app.state(parts[2]))
                if len(parts)>=3 and parts[0]=='files':
                    p=app.job_dir(parts[1]);sub='/'.join(parts[2:]);target=(p/sub).resolve()
                    if not target.is_relative_to(p.resolve()) or not (sub.startswith('frames/') or target.suffix in ('.zip','.mp4','.log')):raise ValueError('file not public')
                    return self.file(target)
                return self.send_json({'error':'not found'},404)
            except (ValueError,KeyError,TypeError) as e:self.send_json({'error':str(e)},400)
        def do_POST(self):
            try:
                origin=self.headers.get('Origin')
                if origin and urlparse(origin).netloc!=self.headers.get('Host'):return self.send_json({'error':'cross-origin writes rejected'},403)
                path=urlparse(self.path).path
                length=int(self.headers.get('Content-Length',0))
                if path=='/api/upload':
                    if not 0<length<=8*1024**3:raise ValueError('upload must be 1 byte to 8 GB')
                    suffix=Path(self.headers.get('X-Filename','')).suffix.lower()
                    if suffix not in ('.mp4','.mkv','.mov','.avi','.json'):raise ValueError('upload video or JSON only')
                    target=app.root/'uploads'/(uuid.uuid4().hex+suffix);remaining=length
                    with target.open('wb') as f:
                        while remaining:
                            chunk=self.rfile.read(min(1024*1024,remaining))
                            if not chunk:raise ValueError('incomplete upload')
                            f.write(chunk);remaining-=len(chunk)
                    return self.send_json({'path':str(target)})
                if length>2*1024*1024:raise ValueError('request too large')
                if 'application/json' not in self.headers.get('Content-Type',''):raise ValueError('JSON content type required')
                body=json.loads(self.rfile.read(length) or b'{}');parts=path.strip('/').split('/')
                if path=='/api/jobs':return self.send_json(app.create_job(body),201)
                if path=='/api/training':return self.send_json(app.create_training(body),201)
                if len(parts)==4 and parts[:2]==['api','jobs']:
                    if parts[3]=='review':return self.send_json(app.review(parts[2],body))
                    if parts[3]=='export':return self.send_json(app.export(parts[2],bool(body.get('training'))))
                    if parts[3]=='render':
                        p=app.job_dir(parts[2]);state=app.state(parts[2])
                        if state.get('status')!='complete':raise ValueError('job not complete')
                        from .render import render_video
                        target=render_video(p,state)
                        return self.send_json({'url':f'/files/{parts[2]}/{target.name}'})
                if len(parts)==4 and parts[:2]==['api','training'] and parts[3]=='stop':
                    from .training import stop
                    return self.send_json(stop(app.root,parts[2]))
                return self.send_json({'error':'not found'},404)
            except (ValueError,KeyError,TypeError) as e:self.send_json({'error':str(e)},400)
            except Exception as e:self.send_json({'error':type(e).__name__+': '+str(e)},500)
    return ThreadingHTTPServer((host,port),Handler)

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',default='data');p.add_argument('--allowed-root',default=str(Path.cwd()));p.add_argument('--port',type=int,default=8768);p.add_argument('--host',default='127.0.0.1');a=p.parse_args()
    app=Application(a.root,a.allowed_root);http=make_server(app,a.port,a.host)
    print(f'NBA Assist: http://127.0.0.1:{a.port}',flush=True);http.serve_forever()
if __name__=='__main__':main()
