"""Storage and executor-neutral contracts. Credentials are read only by SDKs."""
from __future__ import annotations
import hashlib,json,os,re,uuid
from dataclasses import dataclass,asdict,field
from pathlib import Path

class LocalStore:
    def __init__(self,root):self.root=Path(root).resolve();self.root.mkdir(parents=True,exist_ok=True)
    def path(self,key):
        if not key or key.startswith('/') or '..' in Path(key).parts:raise ValueError('unsafe object key')
        p=(self.root/key).resolve()
        if not p.is_relative_to(self.root):raise ValueError('unsafe object key')
        return p
    def put_bytes(self,key,data):p=self.path(key);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);return str(p)
    def get_bytes(self,key):return self.path(key).read_bytes()
    def put_file(self,key,source):return self.put_bytes(key,Path(source).read_bytes())
    def uri(self,key):return str(self.path(key))

class S3Store:
    def __init__(self,bucket,prefix=''):
        try:import boto3
        except ImportError as e:raise RuntimeError('Install boto3 to use NBA_STORAGE=s3') from e
        if not bucket or not re.fullmatch(r'[a-z0-9.-]{3,63}',bucket):raise ValueError('invalid S3 bucket')
        self.client=boto3.client('s3',endpoint_url=os.getenv('NBA_S3_ENDPOINT') or None);self.bucket=bucket;self.prefix=prefix.strip('/')
    def key(self,key):
        if not key or key.startswith('/') or '..' in Path(key).parts:raise ValueError('unsafe object key')
        return '/'.join(x for x in (self.prefix,key) if x)
    def put_bytes(self,key,data):self.client.put_object(Bucket=self.bucket,Key=self.key(key),Body=data);return self.uri(key)
    def get_bytes(self,key):return self.client.get_object(Bucket=self.bucket,Key=self.key(key))['Body'].read()
    def put_file(self,key,source):self.client.upload_file(str(source),self.bucket,self.key(key));return self.uri(key)
    def uri(self,key):return f's3://{self.bucket}/{self.key(key)}'

def make_store(root='data'):
    kind=os.getenv('NBA_STORAGE','local').lower()
    if kind=='local':return LocalStore(root)
    if kind=='s3':return S3Store(os.getenv('NBA_S3_BUCKET',''),os.getenv('NBA_S3_PREFIX','nba-assist'))
    raise ValueError('NBA_STORAGE must be local or s3')

@dataclass(frozen=True)
class JobSpec:
    game_id:str;input_uri:str;model_uri:str;output_uri:str;executor:str='local';custom_model_uri:str|None=None;seconds:float=30;sample_fps:float=10;start:float=0;width:int=1280;job_id:str=''
    schema:str='nba.assist.job.v1'
    options:dict=field(default_factory=dict)
    def __post_init__(self):
        if not self.job_id:object.__setattr__(self,'job_id',uuid.uuid4().hex[:16])
        if self.executor not in ('local','aws-batch','sagemaker'):raise ValueError('unsupported executor')
        if not self.game_id or not self.input_uri or not self.model_uri or not self.output_uri:raise ValueError('job URIs and game_id are required')
        if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',self.job_id):raise ValueError('invalid job id')
        if not 0<self.seconds<=7200 or not 0<self.sample_fps<=30 or self.start<0:raise ValueError('invalid time bounds')
        if set(self.options)-{'team_colors','roster','ocr','device','imgsz','aliases'}:raise ValueError('unsupported job options')
        if self.executor!='local' and any(not u.startswith('s3://') for u in [self.input_uri,self.model_uri,self.output_uri]+([self.custom_model_uri] if self.custom_model_uri else [])):raise ValueError('AWS jobs require S3 URIs')
    @property
    def id(self):return self.job_id
    def to_dict(self):return asdict(self)
    def json(self):return json.dumps(self.to_dict(),ensure_ascii=False,sort_keys=True)

def content_sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()
