"""CLI entry points for agents and reproducible dataset/evaluation work."""
import argparse,json
from pathlib import Path
from .export import build_dataset
from .evaluate import detection_metrics,event_metrics

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def main():
    p=argparse.ArgumentParser();sub=p.add_subparsers(dest='command',required=True)
    d=sub.add_parser('dataset');d.add_argument('--archives',nargs='+',required=True);d.add_argument('--splits',required=True);d.add_argument('--out',required=True)
    e=sub.add_parser('evaluate');e.add_argument('--predictions',required=True);e.add_argument('--truth',required=True);e.add_argument('--events',action='store_true');e.add_argument('--out',required=True)
    a=p.parse_args()
    if a.command=='dataset':print(json.dumps(build_dataset(a.archives,read(a.splits),a.out)));return
    result=(event_metrics if a.events else detection_metrics)(read(a.predictions),read(a.truth));Path(a.out).write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps(result))
if __name__=='__main__':main()
