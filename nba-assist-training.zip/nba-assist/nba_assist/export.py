"""Review exports share the exact same reducer as the browser."""
import json, zipfile, uuid
from pathlib import Path
from .core import reduce_reviews, approved_frames, KINDS, merge_event

def check_splits(splits):
    seen={}
    for split,games in splits.items():
        if split not in ('train','val','test'):raise ValueError('invalid split')
        for game in games:
            if game in seen:raise ValueError(f'game {game} occurs in both {seen[game]} and {split}')
            seen[game]=split
    return seen

def merged_events(events,revisions):
    result={e['id']:dict(e) for e in events}
    for r in revisions:
        if r['op']=='event':
            event=r['event'];result[event['id']]=merge_event(result.get(event['id']),event)
    return list(result.values())

def make_export(directory, job, observations, revisions, events, training=False):
    directory=Path(directory)
    rows=reduce_reviews(observations,revisions,job['width'],job['height'])
    approved=approved_frames(revisions)
    selected=[f for f in job['frames'] if not training or f['index'] in approved]
    target=directory/('training-'+uuid.uuid4().hex[:10]+'.zip' if training else 'review-'+uuid.uuid4().hex[:10]+'.zip')
    w,h=job['width'],job['height']
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
        def js(name,obj):z.writestr(name,json.dumps(obj,ensure_ascii=False,indent=2))
        corrected_frames=[]
        scene_by_frame={str(r['frame']):r['scene'] for r in revisions if r.get('op')=='scene'}
        for f in selected: corrected_frames.append({**f,'scene':scene_by_frame.get(str(f['index']),f.get('scene','unreviewed')),'reviewed':f['index'] in approved})
        js('manifest.json',{'schema':'nba.assist.export.v1','game_id':job['game_id'],'job_id':job['id'],
                           'training':training,'frames':len(selected),'approved_frames':sorted(approved),
                           'classes':list(KINDS),'split_policy':'assign by game_id; never split frames of one game across sets',
                           'model_provenance':job.get('model_provenance',{}),'source':job.get('source'),
                           'frames_metadata':corrected_frames,'width':w,'height':h})
        ids={f['index'] for f in selected}
        js('observations.json',[r for r in rows if r['frame'] in ids])
        js('events.json',merged_events(events,revisions));js('revisions.json',revisions)
        z.writestr('classes.txt','\n'.join(KINDS)+'\n')
        for f in selected:
            stem=Path(f['file']).stem; image=directory/'frames'/f['file']
            if not image.is_file():raise ValueError('missing saved review frame')
            z.write(image,'images/'+f['file'])
            frame_rows=[r for r in rows if r['frame']==f['index']]
            labels=[];shapes=[]
            for r in frame_rows:
                x1,y1,x2,y2=r['bbox'];cls=KINDS.index(r['kind'])
                labels.append(f'{cls} {(x1+x2)/2/w:.6f} {(y1+y2)/2/h:.6f} {(x2-x1)/w:.6f} {(y2-y1)/h:.6f}')
                shapes.append({'label':r['kind'],'points':[[x1,y1],[x2,y2]],'group_id':None,'shape_type':'rectangle',
                               'flags':{},'description':json.dumps({'track_id':r.get('track_id'),'team':r.get('team'),'player_id':r.get('player_id'),'status':r.get('review_status','unreviewed')})})
            z.writestr('labels/'+stem+'.txt','\n'.join(labels)+ ('\n' if labels else ''))
            js('labelme/'+stem+'.json',{'version':'5.5.0','flags':{'frame_reviewed':f['index'] in approved},'shapes':shapes,
                                       'imagePath':'../images/'+f['file'],'imageData':None,'imageWidth':w,'imageHeight':h})
    return target

def build_dataset(archives, splits, output):
    """Only consume reviewed exports; filenames are namespaced by archive hash."""
    import hashlib
    root=Path(output);mapping=check_splits(splits)
    if root.exists():raise ValueError('dataset output must not exist')
    validated=[]
    for archive in archives:
        with zipfile.ZipFile(archive) as z:
            m=json.loads(z.read('manifest.json'))
            if not m.get('training'):raise ValueError('only human-reviewed training exports are accepted')
            if m['game_id'] not in mapping:raise ValueError('game missing from split manifest')
            validated.append((archive,m,mapping[m['game_id']]))
    if not validated:raise ValueError('no archives')
    root.mkdir(parents=True)
    counts={s:0 for s in ('train','val','test')}
    for archive,m,split in validated:
        prefix=hashlib.sha256(Path(archive).read_bytes()).hexdigest()[:12]
        with zipfile.ZipFile(archive) as z:
            for name in z.namelist():
                parts=Path(name).parts
                if len(parts)!=2 or parts[0] not in ('images','labels'):continue
                dest=root/parts[0]/split/(prefix+'_'+parts[1]);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(name))
                if parts[0]=='images':counts[split]+=1
    for s in counts:
        (root/'images'/s).mkdir(parents=True,exist_ok=True);(root/'labels'/s).mkdir(parents=True,exist_ok=True)
    (root/'data.yaml').write_text('path: '+json.dumps(str(root.resolve()))+'\ntrain: images/train\nval: images/val\ntest: images/test\nnames: '+json.dumps(list(KINDS))+'\n')
    (root/'split_manifest.json').write_text(json.dumps({'games':splits,'image_counts':counts},indent=2))
    return counts
