"""Browser job bridge: local inference stays local; AWS jobs round-trip via S3."""
import json,os,time,shutil,tempfile
from pathlib import Path
from .cloud import make_store,JobSpec,content_sha256
from .executor import submit,monitor
from .cloud_runtime import fetch,restore,publish

def execute_cloud(directory):
    p=Path(directory);c=json.loads((p/'config.json').read_text(encoding='utf8'))
    if os.getenv('NBA_STORAGE','local')!='s3':raise ValueError('AWS execution requires NBA_STORAGE=s3')
    store=make_store()
    def upload(path):
        key='assets/'+content_sha256(path)+Path(path).suffix.lower();return store.put_file(key,path)
    options={k:c[k] for k in ('team_colors','roster','ocr','device','imgsz','aliases') if k in c}
    if c.get('roster_path') and 'roster' not in options:options['roster']=json.loads(Path(c['roster_path']).read_text(encoding='utf-8-sig'))
    if c.get('pbp_path') or c.get('gallery_path'):raise ValueError('Cloud jobs currently accept inline roster/teams; import PBP/gallery in local mode')
    spec=JobSpec(c['game_id'],upload(c['source']),upload(c['model']),store.uri('results'),executor=os.environ['NBA_EXECUTOR'],custom_model_uri=upload(c['custom_model']) if c.get('custom_model') else None,seconds=c['seconds'],sample_fps=c['sample_fps'],start=c.get('start',0),width=c.get('width',1280),job_id=c['id'],options=options)
    receipt=submit(spec);(p/'cloud_receipt.json').write_text(json.dumps(receipt),encoding='utf8')
    m=json.loads((p/'manifest.json').read_text());m.update(status='running',executor=spec.executor,cloud_receipt=receipt);(p/'manifest.json').write_text(json.dumps(m),encoding='utf8')
    deadline=time.monotonic()+int(os.getenv('NBA_MONITOR_MAX_SECONDS','86400'))
    while time.monotonic()<deadline:
        info=monitor(receipt)
        if spec.executor=='aws-batch':
            if not info:raise RuntimeError('AWS Batch job missing')
            status=info[0]['status'];failure=info[0].get('statusReason','')
        else:status=info['TrainingJobStatus'];failure=info.get('FailureReason','')
        if status in ('FAILED','Failed','Stopped'):raise RuntimeError('Cloud job failed: '+failure)
        if status in ('SUCCEEDED','Completed'):break
        time.sleep(15)
    else:raise TimeoutError('Local monitoring timed out; remote job may still run. Resume monitoring using cloud_receipt.json.')
    with tempfile.TemporaryDirectory() as tmp:
        archive=fetch(spec.output_uri+'/'+spec.id+'/result.zip',Path(tmp)/'result.zip')
        restored=restore(archive,Path(tmp)/'restored')
        for f in restored.iterdir():
            if f.name in ('config.json','job.json'):continue
            if f.is_dir():shutil.copytree(f,p/f.name,dirs_exist_ok=True)
            else:shutil.copy2(f,p/f.name)

def mirror_local_result(directory):
    if os.getenv('NBA_STORAGE','local')!='s3':return
    p=Path(directory);c=json.loads((p/'config.json').read_text(encoding='utf8'));store=make_store()
    spec=JobSpec(c['game_id'],c['source'],c['model'],store.uri('results'),job_id=c['id'])
    uri=publish(p,spec)
    (p/'cloud_receipt.json').write_text(json.dumps({'executor':'local','result_uri':uri}),encoding='utf8')
