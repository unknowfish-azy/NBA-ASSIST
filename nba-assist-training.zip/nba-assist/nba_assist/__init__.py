"""NBA Assist: evidence-preserving basketball video review."""
