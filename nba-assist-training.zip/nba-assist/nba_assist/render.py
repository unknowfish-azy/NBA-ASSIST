from pathlib import Path
import uuid,subprocess

def render_video(job_dir,state):
    """Render reviewed sample frames; no fabricated in-between measurements."""
    import cv2
    directory=Path(job_dir);stem='annotated-'+uuid.uuid4().hex[:10]
    raw=directory/(stem+'-raw.mp4');out=directory/(stem+'.mp4')
    fps=state.get('sample_fps',5);w,h=state['width'],state['height']
    writer=cv2.VideoWriter(str(raw),cv2.VideoWriter_fourcc(*'mp4v'),fps,(w,h))
    if not writer.isOpened():raise RuntimeError('Video encoder unavailable')
    by={}
    for r in state['observations']:by.setdefault(r['frame'],[]).append(r)
    try:
        for f in state['frames']:
            frame=cv2.imread(str(directory/'frames'/f['file']))
            if frame is None:raise ValueError('Missing review frame')
            for r in by.get(f['index'],[]):
                x1,y1,x2,y2=map(int,r['bbox']);color=(100,170,255) if r.get('team')=='HOU' else (255,190,100) if r.get('team')=='DAL' else (190,215,180)
                cv2.rectangle(frame,(x1,y1),(x2,y2),color,2)
                label=f"{r.get('team') or '?'} {r.get('player_id') or r['kind']} T{r.get('track_id') or '?'}"
                cv2.putText(frame,label,(x1,max(18,y1-4)),cv2.FONT_HERSHEY_SIMPLEX,.5,color,1)
            cv2.putText(frame,f"source {f['timestamp']:.2f}s | sampled {fps:.2f}fps | predictions require review",(12,h-15),cv2.FONT_HERSHEY_SIMPLEX,.55,(220,240,240),1)
            for e in state.get('events',[]):
                if e.get('start') is not None and e['start']<=f['timestamp']<=e.get('end',e['start']) and e.get('status')!='rejected':
                    cv2.putText(frame,f"{e['kind']} [{e['status']}]",(12,30),cv2.FONT_HERSHEY_SIMPLEX,.7,(80,230,255),2)
            writer.write(frame)
    finally:writer.release()
    try:
        import imageio_ffmpeg
        subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(),'-y','-i',str(raw),'-c:v','libx264','-pix_fmt','yuv420p','-movflags','+faststart',str(out)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,timeout=180)
        raw.unlink();return out
    except ImportError:
        raw.rename(out);return out
