"""Safe, resumable local training-script runner."""
from __future__ import annotations
import json,os,re,signal,subprocess,time,uuid,sys,hashlib,threading
from dataclasses import dataclass,asdict,field
from pathlib import Path

@dataclass(frozen=True)
class TrainingSpec:
    game_id:str;script:str;args:list[str];workdir:str;output_dir:str;backend:str='local';job_id:str='';env:dict[str,str]=field(default_factory=dict);max_seconds:int=7200
    schema:str='nba.assist.training.v1'
    def __post_init__(self):
        if not self.job_id:object.__setattr__(self,'job_id',uuid.uuid4().hex[:16])
        if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',self.job_id):raise ValueError('invalid training job id')
        if self.backend not in ('local','aws-batch','sagemaker'):raise ValueError('unsupported training backend')
        if not self.game_id or not isinstance(self.args,list) or any(not isinstance(x,str) for x in self.args):raise ValueError('invalid training fields')
        if not 1<=self.max_seconds<=172800:raise ValueError('max_seconds out of bounds')
    def to_dict(self):return asdict(self)
    def json(self):return json.dumps(self.to_dict(),ensure_ascii=False,sort_keys=True)

def validate_spec(spec,allowed_root):
    root=Path(allowed_root).resolve();script=Path(spec.script).resolve();work=Path(spec.workdir).resolve();out=Path(spec.output_dir).resolve()
    for p in (script,work,out):
        if not p.is_relative_to(root):raise ValueError('training path outside allowed root')
    if not script.is_file():raise ValueError('training script not found')
    if script.suffix.lower() not in ('.py','.py3'):raise ValueError('training script must be Python')
    if not work.is_dir():raise ValueError('training workdir not found')
    if any(any(ch in arg for ch in (';','&&','||','`','$(','>','<','\n','\r')) for arg in spec.args):raise ValueError('shell syntax is forbidden in training args')
    if any(not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*',k) for k in spec.env):raise ValueError('invalid environment variable name')
    if any(k.upper() in ('AWS_SECRET_ACCESS_KEY','AWS_SESSION_TOKEN','AWS_ACCESS_KEY_ID') for k in spec.env):raise ValueError('credentials cannot be embedded in job')
    return {'script':str(script),'workdir':str(work),'output_dir':str(out),'args':list(spec.args)}

def write_status(job,value):
    tmp=job/'status.tmp';tmp.write_text(json.dumps(value),encoding='utf8');os.replace(tmp,job/'status.json')

def run_local(spec,root,python=None,allowed_root=None):
    paths=validate_spec(spec,allowed_root or root);job=Path(root).resolve()/'training_jobs'/spec.job_id;job.mkdir(parents=True,exist_ok=False)
    if Path(paths['output_dir']).exists() and any(Path(paths['output_dir']).iterdir()):raise ValueError('output directory must be empty for a new training job')
    Path(paths['output_dir']).mkdir(parents=True,exist_ok=True)
    data=spec.to_dict();data.update(script=paths['script'],workdir=paths['workdir'],output_dir=paths['output_dir'])
    (job/'spec.json').write_text(json.dumps(data),encoding='utf8')
    (job/'runner.json').write_text(json.dumps({'python':python or sys.executable}),encoding='utf8')
    write_status(job,{'id':spec.job_id,'status':'queued','created_at':time.time(),'script_sha256':hashlib.sha256(Path(spec.script).read_bytes()).hexdigest()})
    with (job/'supervisor.log').open('w',encoding='utf8') as log:
        proc=subprocess.Popen([sys.executable,'-m','nba_assist.training_worker','--job',str(job)],cwd=str(Path(__file__).resolve().parent.parent),stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=os.name!='nt',creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
    threading.Thread(target=proc.wait,daemon=True).start()
    return {'job_id':spec.job_id,'status':'queued','supervisor_pid':proc.pid,'job_dir':str(job)}

def job_path(root,job_id):
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',job_id):raise ValueError('invalid training job id')
    job=Path(root)/'training_jobs'/job_id
    if not job.is_dir():raise ValueError('training job not found')
    return job

def refresh(root,job_id):
    job=job_path(root,job_id);status=json.loads((job/'status.json').read_text(encoding='utf8'))
    if (job/'cloud_receipt.json').exists():
        from .training_cloud import cloud_status
        return cloud_status(json.loads((job/'cloud_receipt.json').read_text(encoding='utf8')))
    status['log_tail']=''
    if (job/'train.log').exists():
        with (job/'train.log').open('rb') as f:f.seek(max(0,(job/'train.log').stat().st_size-12000));status['log_tail']=f.read().decode('utf8','replace')
    spec=json.loads((job/'spec.json').read_text(encoding='utf8'));out=Path(spec['output_dir']).resolve()
    status['artifacts']=[{'path':str(f.relative_to(out)),'bytes':f.stat().st_size} for f in out.rglob('*') if f.is_file() and f.resolve().is_relative_to(out)][:1000]
    metrics=out/'metrics.json'
    if metrics.is_file() and metrics.stat().st_size<1024*1024:
        try:status['metrics']=json.loads(metrics.read_text(encoding='utf8'))
        except (ValueError,OSError):pass
    return status

def stop(root,job_id):
    job=job_path(root,job_id);status=refresh(root,job_id)
    if (job/'cloud_receipt.json').exists():
        from .training_cloud import cloud_stop
        return cloud_stop(json.loads((job/'cloud_receipt.json').read_text(encoding='utf8')))
    if status['status'] in ('queued','running'):(job/'cancel').touch();status['stop_requested']=True
    return status
