"""Detector fusion and bounded video inference helpers."""
from .core import iou
from pathlib import Path

def validate_config(config):
    if not config.get('game_id') or not config.get('source'): raise ValueError('game_id and source are required')
    seconds=float(config.get('seconds',0));fps=float(config.get('sample_fps',0))
    if not 0<seconds<=7200: raise ValueError('seconds must be in (0,7200]')
    if not 0<fps<=30: raise ValueError('sample_fps must be in (0,30]')
    if float(config.get('width',960))<320: raise ValueError('width too small')
    return dict(config,seconds=seconds,sample_fps=fps)

def fuse_detections(generic,custom):
    out=[dict(x) for x in generic]
    for candidate in custom:
        overlaps=[(iou(candidate['bbox'],r['bbox']),i) for i,r in enumerate(out) if r['kind']==candidate['kind']]
        best=max(overlaps,default=(0,None))
        if best[0]>=.45:
            target=out[best[1]]
            if candidate.get('candidate_player_id'):
                target['name_candidate']={'player_id':str(candidate['candidate_player_id']),'score':candidate.get('confidence',0),'basis':'closed_set_detector'}
            if candidate.get('confidence',0)>target.get('confidence',0):target['confidence']=candidate['confidence']
        else: out.append(dict(candidate))
    return out

def color_candidate(bgr):
    import cv2, numpy as np
    if bgr is None or bgr.size==0:return {'color':None,'score':0,'status':'unknown'}
    hsv=cv2.cvtColor(bgr,cv2.COLOR_BGR2HSV); h,s,v=np.median(hsv.reshape(-1,3),axis=0)
    if s<45 and v>155:return {'color':'white','score':.7,'status':'ambiguous'}
    if (h<12 or h>168) and s>50:return {'color':'red','score':.7,'status':'candidate'}
    if 95<h<140 and s>40:return {'color':'blue','score':.7,'status':'candidate'}
    return {'color':'unknown','score':.2,'status':'unknown'}

def run_ultralytics(source, model_path, output, seconds=10, sample_fps=3, width=960, aliases=None):
    """Run a bounded sample. Raises if optional runtime is unavailable."""
    import cv2, json, time
    try: from ultralytics import YOLO
    except ImportError as e: raise RuntimeError('ultralytics is required for GPU inference') from e
    cap=cv2.VideoCapture(str(source))
    if not cap.isOpened(): raise ValueError('cannot open video')
    fps=cap.get(cv2.CAP_PROP_FPS) or 25; total=min(int(seconds*sample_fps),int(seconds*fps)+1)
    every=max(1,round(fps/sample_fps)); model=YOLO(str(model_path));rows=[];frame=0;start=time.time()
    while frame<total*every:
        ok,img=cap.read()
        if not ok:break
        if frame%every: frame+=1;continue
        result=model.track(img,persist=True,tracker='bytetrack.yaml',verbose=False,conf=.25)[0]
        for j,b in enumerate(result.boxes):
            cls=int(b.cls.item()); label=str(result.names[cls]); xy=b.xyxy[0].tolist();kind='ball' if 'ball' in label.lower() else 'player' if 'person' in label.lower() or label.lower() in (aliases or {}) else None
            if not kind:continue
            tid=int(b.id.item()) if b.id is not None else None
            row={'id':f'{frame}-{j}','frame':frame,'timestamp':round(frame/fps,3),'shot_id':0,'track_id':f'0:{tid}' if tid is not None else None,'kind':kind,'bbox':[round(x,2) for x in xy],'confidence':round(float(b.conf.item()),4),'detector_label':label}
            if kind=='player':
                x1,y1,x2,y2=map(int,xy);row['team_evidence']=color_candidate(img[max(0,y1+int((y2-y1)*.15)):max(1,y1+int((y2-y1)*.55)),max(0,x1+int((x2-x1)*.2)):max(1,x1+int((x2-x1)*.8))])
            rows.append(row)
        frame+=1
    cap.release();Path(output).write_text(json.dumps({'observations':rows,'frames_processed':frame//every,'elapsed_s':time.time()-start},ensure_ascii=False),encoding='utf8')
    return rows
